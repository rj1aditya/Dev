# DSA Practice Webpage

A static LeetCode DSA practice dashboard generated from the local question bank workbook.

## Open the Website

Open `site/index.html` in a browser.

## Features

- Search questions by title, topic, or hint
- Filter by topic, source, and completion status
- Click any problem title to open the LeetCode problem page
- Separate resource links for available tutorials or notes
- Mark questions done or starred with browser-local progress storage
- Topic progress dashboard
- Review view for questions that still need topic cleanup

## Files

- `site/` contains the static website.
- `site/data.js` contains the embedded question data.
- `outputs/leetcode_topic_wise_questions.xlsx` is the cleaned workbook used to generate the site data.
- `scripts/` contains workbook build and verification scripts.
