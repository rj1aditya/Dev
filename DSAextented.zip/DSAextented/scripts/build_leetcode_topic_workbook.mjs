import fs from "node:fs/promises";
import path from "node:path";
import { FileBlob, SpreadsheetFile, Workbook } from "@oai/artifact-tool";

const sourcePath = "/Users/rj1aditya/Downloads/top150 Leetcode.xlsx";
const outputDir = "/Users/rj1aditya/Documents/DSA/outputs";
const outputPath = path.join(outputDir, "leetcode_topic_wise_questions.xlsx");

function colLetter(n) {
  let s = "";
  while (n > 0) {
    const m = (n - 1) % 26;
    s = String.fromCharCode(65 + m) + s;
    n = Math.floor((n - m) / 26);
  }
  return s;
}

function cleanText(value) {
  if (value === null || value === undefined) return "";
  return String(value).replace(/\s+/g, " ").trim();
}

function titleCase(value) {
  return value
    .toLowerCase()
    .split(" ")
    .filter(Boolean)
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
    .join(" ");
}

const topicMap = new Map([
  ["2 POINTER", "Two Pointers"],
  ["2 POINTERS", "Two Pointers"],
  ["TWO POINTERS", "Two Pointers"],
  ["ARRAY", "Array"],
  ["BINARY SEARCH", "Binary Search"],
  ["BITWISE", "Bitwise"],
  ["BST", "BST"],
  ["DEQUEUE", "Deque"],
  ["DP", "DP"],
  ["GRAPH", "Graph"],
  ["GREEDY", "Greedy"],
  ["HASH", "Hash Map"],
  ["HASHMAP", "Hash Map"],
  ["KADENCE ALGO", "Kadane's Algorithm"],
  ["LINKED LIST", "Linked List"],
  ["LPS", "LPS"],
  ["MAP", "Hash Map"],
  ["MATHS", "Math"],
  ["MATRIX", "Matrix"],
  ["MULTIMAP", "Multimap"],
  ["PQ", "Priority Queue"],
  ["RECURSION", "Recursion"],
  ["SEMAPHORE", "Semaphore"],
  ["SET", "Set"],
  ["SLIDING WINDOW", "Sliding Window"],
  ["STACK", "Stack"],
  ["STRING", "String"],
  ["TREE", "Tree"],
  ["TRIE", "Trie"],
]);

function normalizeToken(raw) {
  const key = cleanText(raw).toUpperCase();
  return topicMap.get(key) ?? titleCase(cleanText(raw));
}

function normalizeTopic(raw) {
  const original = cleanText(raw);
  if (!original) {
    return { primary: "Uncategorized", tags: "Uncategorized" };
  }

  const tokens = original
    .split(/[\/,&+]| and /i)
    .map((part) => cleanText(part))
    .filter(Boolean);

  const normalized = [...new Set(tokens.length ? tokens.map(normalizeToken) : [normalizeToken(original)])];
  return {
    primary: normalized[0] || "Uncategorized",
    tags: normalized.join(", ") || "Uncategorized",
  };
}

function extractProblemNumber(title) {
  const match = cleanText(title).match(/^(\d+)[\.\s]/);
  return match ? Number(match[1]) : "";
}

function extractUrl(...values) {
  for (const value of values) {
    const text = cleanText(value);
    const match = text.match(/https?:\/\/\S+/i);
    if (match) return match[0];
  }
  return "";
}

function leetcodeSlug(title) {
  return cleanText(title)
    .replace(/^\d+\.?\s*/, "")
    .replace(/\(.*?\)/g, (match) => match.replace(/[()]/g, ""))
    .replace(/[^a-zA-Z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .toLowerCase();
}

function problemUrl(title, ...values) {
  const existing = extractUrl(...values);
  if (/leetcode\.com\/problems\//i.test(existing)) return existing;
  const slug = leetcodeSlug(title);
  return slug ? `https://leetcode.com/problems/${slug}/` : "";
}

function stripUrl(value) {
  return cleanText(value).replace(/https?:\/\/\S+/gi, "").trim();
}

function addTitle(sheet, title, subtitle, widthCols) {
  const end = colLetter(widthCols);
  sheet.getRange(`A1:${end}1`).merge();
  sheet.getRange("A1").values = [[title]];
  sheet.getRange(`A1:${end}1`).format.fill = { color: "#EAF2F8" };
  sheet.getRange("A1").format.font = { name: "Aptos Display", color: "#17324D", bold: true, size: 18 };
  sheet.getRange("A1").format.horizontalAlignment = "left";
  sheet.getRange("A1").format.verticalAlignment = "center";
  sheet.getRange("A1").format.rowHeightPx = 34;

  sheet.getRange(`A2:${end}2`).merge();
  sheet.getRange("A2").values = [[subtitle]];
  sheet.getRange(`A2:${end}2`).format.fill = { color: "#EAF2F8" };
  sheet.getRange("A2").format.font = { name: "Aptos", color: "#2B3A42", italic: true, size: 10 };
  sheet.getRange("A2").format.horizontalAlignment = "left";
  sheet.getRange("A2").format.verticalAlignment = "center";
  sheet.getRange("A2").format.rowHeightPx = 24;
}

function styleTable(sheet, rangeAddress, tableName) {
  const table = sheet.tables.add(rangeAddress, true, tableName);
  table.style = "TableStyleMedium2";
  table.showFilterButton = true;
  table.showBandedRows = true;
  return table;
}

function setWidths(sheet, widths) {
  widths.forEach((width, i) => {
    sheet.getRange(`${colLetter(i + 1)}:${colLetter(i + 1)}`).format.columnWidth = width;
  });
}

const input = await FileBlob.load(sourcePath);
const sourceWorkbook = await SpreadsheetFile.importXlsx(input);

function valuesForSheet(name) {
  const sheet = sourceWorkbook.worksheets.getItem(name);
  return sheet.getUsedRange(true).values;
}

const rows = [];
const sheetConfigs = [
  {
    sourceSheet: "Leetcode must do question",
    titleHeader: "Title",
    topicHeader: "topic",
    duplicateHeader: "",
    hintHeader: "Hint",
    noteHeader: "",
  },
  {
    sourceSheet: "Microsoft 3",
    titleHeader: "Topics",
    topicHeader: "Data Structure used",
    duplicateHeader: "mark duplicate",
    hintHeader: "Hint",
    noteHeader: "",
  },
];

for (const config of sheetConfigs) {
  const values = valuesForSheet(config.sourceSheet);
  const headers = values[0].map(cleanText);
  const titleIdx = headers.indexOf(config.titleHeader);
  const topicIdx = headers.indexOf(config.topicHeader);
  const duplicateIdx = config.duplicateHeader ? headers.indexOf(config.duplicateHeader) : -1;
  const hintIdx = headers.indexOf(config.hintHeader);

  values.slice(1).forEach((row) => {
    const problem = cleanText(row[titleIdx]);
    if (!problem) return;

    const originalTopic = cleanText(row[topicIdx]);
    const { primary, tags } = normalizeTopic(originalTopic);
    const hint = stripUrl(row[hintIdx]);
    const resourceLink = extractUrl(row[hintIdx], row[4]);
    const platformLink = problemUrl(problem, row[hintIdx], row[4]);
    const noteParts = [];
    if (duplicateIdx >= 0 && cleanText(row[duplicateIdx])) noteParts.push(`Duplicate marker: ${cleanText(row[duplicateIdx])}`);
    if (cleanText(row[4]) && !extractUrl(row[4])) noteParts.push(cleanText(row[4]));

    rows.push({
      sourceSheet: config.sourceSheet,
      problemNumber: extractProblemNumber(problem),
      problem,
      primary,
      tags,
      originalTopic,
      hint,
      platformLink,
      resourceLink,
      notes: noteParts.join(" | "),
    });
  });
}

rows.sort((a, b) => {
  const topicCompare = a.primary.localeCompare(b.primary);
  if (topicCompare) return topicCompare;
  return cleanText(a.problem).localeCompare(cleanText(b.problem), undefined, { numeric: true });
});

const workbook = Workbook.create();
const allSheet = workbook.worksheets.add("All Questions");
const summarySheet = workbook.worksheets.add("Topic Summary");
const reviewSheet = workbook.worksheets.add("Needs Topic Review");

addTitle(
  allSheet,
  "LeetCode Topic-Wise Question Bank",
  "Combined from Leetcode must do question and Microsoft 3. Filter by Primary Topic or Topic Tags.",
  9,
);

const allHeaders = [
  "Source Sheet",
  "Problem #",
  "Problem",
  "Primary Topic",
  "Topic Tags",
  "Original Topic",
  "Hint",
  "Problem Link",
  "Resource Link",
  "Notes",
];
const allData = rows.map((row) => [
  row.sourceSheet,
  row.problemNumber,
  row.problem,
  row.primary,
  row.tags,
  row.originalTopic,
  row.hint,
  row.platformLink,
  row.resourceLink,
  row.notes,
]);
allSheet.getRangeByIndexes(3, 0, allData.length + 1, allHeaders.length).values = [allHeaders, ...allData];
styleTable(allSheet, `A4:J${allData.length + 4}`, "AllQuestions");
allSheet.freezePanes.freezeRows(4);
allSheet.showGridLines = false;
setWidths(allSheet, [26, 10, 42, 20, 30, 22, 58, 38, 34, 30]);
allSheet.getRange(`A4:J${allData.length + 4}`).format = {
  verticalAlignment: "top",
  wrapText: true,
};
allSheet.getRange(`B5:B${allData.length + 4}`).format.numberFormat = [["0"]];
allSheet.getRange(`D5:D${allData.length + 4}`).conditionalFormats.add("containsText", {
  text: "Uncategorized",
  format: { fill: { color: "#FCE4D6" }, font: { color: "#9C5700", bold: true } },
});

const summary = new Map();
for (const row of rows) {
  const entry = summary.get(row.primary) ?? {
    topic: row.primary,
    leetcode: 0,
    microsoft: 0,
    total: 0,
  };
  if (row.sourceSheet === "Leetcode must do question") entry.leetcode += 1;
  if (row.sourceSheet === "Microsoft 3") entry.microsoft += 1;
  entry.total += 1;
  summary.set(row.primary, entry);
}
const summaryRows = [...summary.values()].sort((a, b) => b.total - a.total || a.topic.localeCompare(b.topic));

addTitle(
  summarySheet,
  "Topic Summary",
  "Counts by normalized Primary Topic. Use this sheet to choose what to study next.",
  5,
);
const summaryHeaders = ["Primary Topic", "Leetcode must do question", "Microsoft 3", "Total", "Share of Total"];
const totalProblems = rows.length;
summarySheet.getRangeByIndexes(3, 0, summaryRows.length + 1, summaryHeaders.length).values = [
  summaryHeaders,
  ...summaryRows.map((row) => [row.topic, row.leetcode, row.microsoft, row.total, row.total / totalProblems]),
];
styleTable(summarySheet, `A4:E${summaryRows.length + 4}`, "TopicSummary");
summarySheet.freezePanes.freezeRows(4);
summarySheet.showGridLines = false;
setWidths(summarySheet, [26, 24, 16, 12, 14]);
summarySheet.getRange(`B5:D${summaryRows.length + 4}`).format.numberFormat = [["0"]];
summarySheet.getRange(`E5:E${summaryRows.length + 4}`).format.numberFormat = [["0.0%"]];
summarySheet.getRange(`A4:E${summaryRows.length + 4}`).format = {
  verticalAlignment: "middle",
};
summarySheet.getRange(`D5:D${summaryRows.length + 4}`).conditionalFormats.add("dataBar", {
  color: "#5B9BD5",
});

const uncategorizedRows = rows.filter((row) => row.primary === "Uncategorized");
addTitle(
  reviewSheet,
  "Needs Topic Review",
  "Rows where the source workbook has a problem title but no topic. Fill topics in the source or this output as needed.",
  7,
);
const reviewHeaders = ["Source Sheet", "Problem #", "Problem", "Problem Link", "Suggested Topic", "Hint", "Notes"];
reviewSheet.getRangeByIndexes(3, 0, Math.max(uncategorizedRows.length, 1) + 1, reviewHeaders.length).values = [
  reviewHeaders,
  ...(uncategorizedRows.length
    ? uncategorizedRows.map((row) => [row.sourceSheet, row.problemNumber, row.problem, row.platformLink, "", row.hint, row.notes])
    : [["", "", "No uncategorized questions found.", "", "", "", ""]]),
];
styleTable(reviewSheet, `A4:G${Math.max(uncategorizedRows.length, 1) + 4}`, "NeedsTopicReview");
reviewSheet.freezePanes.freezeRows(4);
reviewSheet.showGridLines = false;
setWidths(reviewSheet, [22, 10, 48, 38, 22, 55, 24]);
reviewSheet.getRange(`A4:G${Math.max(uncategorizedRows.length, 1) + 4}`).format = {
  verticalAlignment: "top",
  wrapText: true,
};

for (const sheet of [allSheet, summarySheet, reviewSheet]) {
  const used = sheet.getUsedRange();
  used.format.font = { name: "Aptos", size: 10 };
}

addTitle(
  allSheet,
  "LeetCode Topic-Wise Question Bank",
  "Combined from Leetcode must do question and Microsoft 3. Click Problem Link to open LeetCode.",
  10,
);
addTitle(
  summarySheet,
  "Topic Summary",
  "Counts by normalized Primary Topic. Use this sheet to choose what to study next.",
  5,
);
addTitle(
  reviewSheet,
  "Needs Topic Review",
  "Rows where the source workbook has a problem title but no topic. Fill topics in the source or this output as needed.",
  6,
);

await fs.mkdir(outputDir, { recursive: true });
const output = await SpreadsheetFile.exportXlsx(workbook);
await output.save(outputPath);

console.log(JSON.stringify({ outputPath, totalRows: rows.length, uncategorized: uncategorizedRows.length }, null, 2));
