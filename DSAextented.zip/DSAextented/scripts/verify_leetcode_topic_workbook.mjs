import fs from "node:fs/promises";
import path from "node:path";
import { FileBlob, SpreadsheetFile } from "@oai/artifact-tool";

const workbookPath = "/Users/rj1aditya/Documents/DSA/outputs/leetcode_topic_wise_questions.xlsx";
const previewDir = "/Users/rj1aditya/Documents/DSA/outputs/leetcode_topic_previews";

const input = await FileBlob.load(workbookPath);
const workbook = await SpreadsheetFile.importXlsx(input);

const overview = await workbook.inspect({
  kind: "workbook,sheet,table",
  maxChars: 6000,
  tableMaxRows: 5,
  tableMaxCols: 9,
});
console.log(overview.ndjson);

const errors = await workbook.inspect({
  kind: "match",
  searchTerm: "#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A",
  options: { useRegex: true, maxResults: 300 },
  summary: "formula error scan",
});
console.log(errors.ndjson);

await fs.mkdir(previewDir, { recursive: true });
for (const [sheetName, range] of [
  ["All Questions", "A1:J24"],
  ["Topic Summary", "A1:E30"],
  ["Needs Topic Review", "A1:F24"],
]) {
  const preview = await workbook.render({ sheetName, range, scale: 1.5, format: "png" });
  const bytes = new Uint8Array(await preview.arrayBuffer());
  await fs.writeFile(path.join(previewDir, `${sheetName.replace(/\s+/g, "_")}.png`), bytes);
}

console.log(JSON.stringify({ previewDir }, null, 2));
