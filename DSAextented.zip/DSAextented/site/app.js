const storageKey = "dsa-practice-state-v1";
const commonNotesKey = "dsa-common-notes-v1";

const state = {
  search: "",
  topic: "all",
  source: "all",
  status: "all",
  selectedId: null,
  done: new Set(),
  starred: new Set(),
  completedDates: {},
  notes: {},
  commonNotes: "",
};

const els = {
  tabs: document.querySelectorAll(".nav-tab"),
  views: {
    practice: document.querySelector("#practiceView"),
    topics: document.querySelector("#topicsView"),
    review: document.querySelector("#reviewView"),
    notes: document.querySelector("#notesView"),
  },
  search: document.querySelector("#searchInput"),
  topic: document.querySelector("#topicFilter"),
  source: document.querySelector("#sourceFilter"),
  status: document.querySelector("#statusFilter"),
  reset: document.querySelector("#resetFilters"),
  random: document.querySelector("#pickRandom"),
  total: document.querySelector("#totalQuestions"),
  done: document.querySelector("#doneQuestions"),
  remaining: document.querySelector("#remainingQuestions"),
  percent: document.querySelector("#progressPercent"),
  today: document.querySelector("#todayCount"),
  resultCount: document.querySelector("#resultCount"),
  topicCount: document.querySelector("#topicCount"),
  reviewCount: document.querySelector("#reviewCount"),
  notesCount: document.querySelector("#notesCount"),
  list: document.querySelector("#questionList"),
  topicGrid: document.querySelector("#topicGrid"),
  reviewList: document.querySelector("#reviewList"),
  notesList: document.querySelector("#notesList"),
  commonNotes: document.querySelector("#commonNotes"),
  focusSource: document.querySelector("#focusSource"),
  focusTopic: document.querySelector("#focusTopic"),
  focusTitle: document.querySelector("#focusTitle"),
  focusHint: document.querySelector("#focusHint"),
  focusProblem: document.querySelector("#focusProblem"),
  focusResource: document.querySelector("#focusResource"),
  focusNotes: document.querySelector("#focusNotes"),
  toggleDone: document.querySelector("#toggleDone"),
  toggleStar: document.querySelector("#toggleStar"),
};

const questions = window.DSA_QUESTIONS || [];
const todayKey = new Date().toISOString().slice(0, 10);

function loadState() {
  try {
    const saved = JSON.parse(localStorage.getItem(storageKey) || "{}");
    state.done = new Set(saved.done || []);
    state.starred = new Set(saved.starred || []);
    state.completedDates = saved.completedDates || {};
    state.notes = saved.notes || {};
    state.commonNotes = localStorage.getItem(commonNotesKey) || "";
  } catch {
    localStorage.removeItem(storageKey);
  }
}

function saveState() {
  localStorage.setItem(
    storageKey,
    JSON.stringify({
      done: [...state.done],
      starred: [...state.starred],
      completedDates: state.completedDates,
      notes: state.notes,
    }),
  );
}

function normalize(value) {
  return String(value || "").toLowerCase();
}

function filteredQuestions() {
  const needle = normalize(state.search);
  return questions.filter((question) => {
    const isDone = state.done.has(question.id);
    const isStarred = state.starred.has(question.id);
    const matchesSearch =
      !needle ||
      normalize(question.problem).includes(needle) ||
      normalize(question.primaryTopic).includes(needle) ||
      normalize(question.topicTags).includes(needle) ||
      normalize(question.hint).includes(needle) ||
      normalize(state.notes[question.id]).includes(needle);
    const matchesTopic = state.topic === "all" || question.primaryTopic === state.topic;
    const matchesSource = state.source === "all" || question.sourceSheet === state.source;
    const matchesStatus =
      state.status === "all" ||
      (state.status === "done" && isDone) ||
      (state.status === "todo" && !isDone) ||
      (state.status === "starred" && isStarred);

    return matchesSearch && matchesTopic && matchesSource && matchesStatus;
  });
}

function uniqueSorted(field) {
  return [...new Set(questions.map((question) => question[field]).filter(Boolean))].sort((a, b) =>
    a.localeCompare(b),
  );
}

function setOptions(select, values, allLabel) {
  select.innerHTML = "";
  const all = document.createElement("option");
  all.value = "all";
  all.textContent = allLabel;
  select.append(all);
  values.forEach((value) => {
    const option = document.createElement("option");
    option.value = value;
    option.textContent = value;
    select.append(option);
  });
}

function questionLabel(question) {
  return question.problemNumber ? `#${question.problemNumber}` : "No #";
}

function selectQuestion(id) {
  state.selectedId = id;
  render();
}

function toggleDone(id) {
  if (state.done.has(id)) {
    state.done.delete(id);
    delete state.completedDates[id];
  } else {
    state.done.add(id);
    state.completedDates[id] = todayKey;
  }
  saveState();
  render();
}

function toggleStar(id) {
  if (state.starred.has(id)) {
    state.starred.delete(id);
  } else {
    state.starred.add(id);
  }
  saveState();
  render();
}

function saveNote(id, value) {
  const note = value.trim();
  if (note) {
    state.notes[id] = value;
  } else {
    delete state.notes[id];
  }
  saveState();
  renderNotes();
}

function saveCommonNotes(value) {
  state.commonNotes = value;
  localStorage.setItem(commonNotesKey, value);
}

function renderStats() {
  const doneCount = state.done.size;
  const total = questions.length;
  const todayDone = Object.values(state.completedDates).filter((date) => date === todayKey).length;
  els.total.textContent = total;
  els.done.textContent = doneCount;
  els.remaining.textContent = Math.max(total - doneCount, 0);
  els.percent.textContent = `${Math.round((doneCount / Math.max(total, 1)) * 100)}%`;
  els.today.textContent = todayDone;
}

function createQuestionRow(question) {
  const row = document.createElement("article");
  row.className = "question-row";
  if (question.id === state.selectedId) row.classList.add("is-selected");
  if (state.done.has(question.id)) row.classList.add("is-done");

  const main = document.createElement("div");
  main.className = "question-main";

  const title = document.createElement("a");
  title.className = "question-title";
  title.textContent = question.problem;
  title.href = question.problemLink || "#";
  title.target = "_blank";
  title.rel = "noreferrer";
  title.addEventListener("click", () => selectQuestion(question.id));

  const sub = document.createElement("span");
  sub.className = "question-sub";
  sub.innerHTML = `<span>${questionLabel(question)}</span><span>${question.primaryTopic}</span><span>${question.sourceSheet}</span>`;

  main.append(title, sub);
  sub.addEventListener("click", () => selectQuestion(question.id));

  const actions = document.createElement("div");
  actions.className = "row-actions";

  const done = document.createElement("button");
  done.type = "button";
  done.title = "Toggle done";
  done.textContent = "✓";
  if (state.done.has(question.id)) done.classList.add("is-active");
  done.addEventListener("click", () => toggleDone(question.id));

  const star = document.createElement("button");
  star.type = "button";
  star.title = "Toggle star";
  star.textContent = state.starred.has(question.id) ? "★" : "☆";
  if (state.starred.has(question.id)) star.classList.add("is-active");
  star.addEventListener("click", () => toggleStar(question.id));

  actions.append(done, star);
  row.append(main, actions);
  return row;
}

function renderList() {
  const shown = filteredQuestions();
  if (!state.selectedId || !questions.some((question) => question.id === state.selectedId)) {
    state.selectedId = shown[0]?.id || questions[0]?.id || null;
  }

  els.resultCount.textContent = `${shown.length} shown`;
  els.list.innerHTML = "";

  if (!shown.length) {
    const empty = document.createElement("p");
    empty.className = "empty-state";
    empty.textContent = "No questions match the current filters.";
    els.list.append(empty);
    return;
  }

  shown.forEach((question) => els.list.append(createQuestionRow(question)));
}

function renderFocus() {
  const selected = questions.find((question) => question.id === state.selectedId);
  if (!selected) return;

  els.focusSource.textContent = selected.sourceSheet;
  els.focusTopic.textContent = selected.primaryTopic;
  els.focusTitle.textContent = selected.problem;
  els.focusTitle.href = selected.problemLink || "#";
  els.focusHint.textContent = selected.hint || selected.notes || "No hint added yet.";
  els.toggleDone.textContent = state.done.has(selected.id) ? "Mark todo" : "Mark done";
  els.toggleStar.textContent = state.starred.has(selected.id) ? "Starred" : "Star";
  els.toggleStar.classList.toggle("is-active", state.starred.has(selected.id));
  els.focusProblem.style.display = selected.problemLink ? "inline-flex" : "none";
  els.focusProblem.href = selected.problemLink || "#";
  els.focusResource.style.display = selected.resourceLink ? "inline-flex" : "none";
  els.focusResource.href = selected.resourceLink || "#";
  els.focusNotes.value = state.notes[selected.id] || "";
}

function topicSummaries() {
  const map = new Map();
  questions.forEach((question) => {
    const entry = map.get(question.primaryTopic) || { topic: question.primaryTopic, total: 0, done: 0 };
    entry.total += 1;
    if (state.done.has(question.id)) entry.done += 1;
    map.set(question.primaryTopic, entry);
  });
  return [...map.values()].sort((a, b) => b.total - a.total || a.topic.localeCompare(b.topic));
}

function renderTopics() {
  const topics = topicSummaries();
  els.topicCount.textContent = `${topics.length} topics`;
  els.topicGrid.innerHTML = "";
  topics.forEach((topic) => {
    const percent = Math.round((topic.done / Math.max(topic.total, 1)) * 100);
    const card = document.createElement("article");
    card.className = "topic-card";
    card.innerHTML = `
      <header>
        <strong>${topic.topic}</strong>
        <span>${topic.done}/${topic.total}</span>
      </header>
      <div class="progress-track"><div class="progress-fill" style="width:${percent}%"></div></div>
    `;
    card.addEventListener("click", () => {
      state.topic = topic.topic;
      els.topic.value = topic.topic;
      switchView("practice");
      render();
    });
    els.topicGrid.append(card);
  });
}

function renderReview() {
  const rows = questions.filter((question) => question.primaryTopic === "Uncategorized");
  els.reviewCount.textContent = `${rows.length} rows`;
  els.reviewList.innerHTML = "";
  rows.forEach((question) => els.reviewList.append(createQuestionRow(question)));
}

function renderNotes() {
  const notedQuestions = questions.filter((question) => (state.notes[question.id] || "").trim());
  els.notesCount.textContent = `${notedQuestions.length} notes`;
  els.notesList.innerHTML = "";
  els.commonNotes.value = state.commonNotes;

  if (!notedQuestions.length) {
    const empty = document.createElement("p");
    empty.className = "empty-state";
    empty.textContent = "No notes yet.";
    els.notesList.append(empty);
    return;
  }

  notedQuestions.forEach((question) => {
    const item = document.createElement("article");
    item.className = "note-card";

    const header = document.createElement("button");
    header.type = "button";
    header.className = "note-card-title";
    header.textContent = question.problem;
    header.addEventListener("click", () => {
      selectQuestion(question.id);
      switchView("practice");
    });

    const meta = document.createElement("span");
    meta.className = "note-card-meta";
    meta.textContent = `${question.primaryTopic} - ${question.sourceSheet}`;

    const body = document.createElement("p");
    body.textContent = state.notes[question.id];

    item.append(header, meta, body);
    els.notesList.append(item);
  });
}

function render() {
  renderStats();
  renderList();
  renderFocus();
  renderTopics();
  renderReview();
  renderNotes();
}

function switchView(view) {
  els.tabs.forEach((tab) => tab.classList.toggle("is-active", tab.dataset.view === view));
  Object.entries(els.views).forEach(([name, element]) => {
    element.classList.toggle("is-active", name === view);
  });
}

function pickRandom() {
  const shown = filteredQuestions();
  if (!shown.length) return;
  const pick = shown[Math.floor(Math.random() * shown.length)];
  selectQuestion(pick.id);
}

function resetFilters() {
  state.search = "";
  state.topic = "all";
  state.source = "all";
  state.status = "all";
  els.search.value = "";
  els.topic.value = "all";
  els.source.value = "all";
  els.status.value = "all";
  render();
}

function bindEvents() {
  els.search.addEventListener("input", (event) => {
    state.search = event.target.value;
    render();
  });
  els.topic.addEventListener("change", (event) => {
    state.topic = event.target.value;
    render();
  });
  els.source.addEventListener("change", (event) => {
    state.source = event.target.value;
    render();
  });
  els.status.addEventListener("change", (event) => {
    state.status = event.target.value;
    render();
  });
  els.reset.addEventListener("click", resetFilters);
  els.random.addEventListener("click", pickRandom);
  els.toggleDone.addEventListener("click", () => state.selectedId && toggleDone(state.selectedId));
  els.toggleStar.addEventListener("click", () => state.selectedId && toggleStar(state.selectedId));
  els.focusNotes.addEventListener("input", (event) => {
    if (state.selectedId) saveNote(state.selectedId, event.target.value);
  });
  els.commonNotes.addEventListener("input", (event) => saveCommonNotes(event.target.value));
  els.tabs.forEach((tab) => tab.addEventListener("click", () => switchView(tab.dataset.view)));
}

loadState();
setOptions(els.topic, uniqueSorted("primaryTopic"), "All topics");
setOptions(els.source, uniqueSorted("sourceSheet"), "All sources");
bindEvents();
render();
