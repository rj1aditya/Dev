window.STRIVER_TUF_TOPICS = [
  {
    "id": "arrays",
    "name": "Arrays",
    "description": "Build fluency with traversal, hashing, prefix sums, and matrix patterns.",
    "symbol": "[]",
    "problems": [
      {
        "title": "Second Largest/Smalles Number",
        "links": [
          "https://bit.ly/3GJie4l"
        ],
        "solution": "./striver-solutions/topics/Array/secondLargestSmallestElem.html",
        "notes": ""
      },
      {
        "title": "Remove Duplicates from Sorted Array",
        "links": [
          "https://bit.ly/3if2k8G"
        ],
        "solution": "./striver-solutions/topics/Array/removeDuplicatesFromSortedArray.html",
        "notes": ""
      },
      {
        "title": "Left Rotate an Array by One",
        "links": [
          "https://bit.ly/3ZeXGrO"
        ],
        "solution": "./striver-solutions/topics/Array/leftRotateByOne.html",
        "notes": ""
      },
      {
        "title": "Rotate array by k step",
        "links": [
          "http://bit.ly/3IQQdrt"
        ],
        "solution": "./striver-solutions/topics/Array/rotateArrayByKStep.html",
        "notes": ""
      },
      {
        "title": "Move Zero's to End",
        "links": [
          "https://bit.ly/3XbsF6k"
        ],
        "solution": "./striver-solutions/topics/Array/moveAllZeroToEnd.html",
        "notes": ""
      },
      {
        "title": "Merge 2 Sorted Array",
        "links": [
          "https://bit.ly/3IpS7Rd"
        ],
        "solution": "./striver-solutions/topics/Array/merge2SortedArray.html",
        "notes": ""
      },
      {
        "title": "Intersection Of Two Sorted Arrays",
        "links": [
          "http://bit.ly/3KSSx3Z"
        ],
        "solution": "./striver-solutions/topics/Array/intersectionOf2SortedArr.html",
        "notes": ""
      },
      {
        "title": "Missing Number",
        "links": [
          "https://bit.ly/3ZdwAkN"
        ],
        "solution": "./striver-solutions/topics/Array/findMissingNumber.html",
        "notes": ""
      },
      {
        "title": "Find The Single Element",
        "links": [
          "https://bit.ly/3VOlEHp"
        ],
        "solution": "./striver-solutions/topics/Array/findTheSinlgeElement.html",
        "notes": "same question is solved in binary search problems - Question 9: Single Element in Sorted Array"
      },
      {
        "title": "Longest Subarray With Sum K",
        "links": [
          "https://bit.ly/3GHyBOS"
        ],
        "solution": "./striver-solutions/topics/Array/longestSubarrayWithSumK.html",
        "notes": ""
      },
      {
        "title": "Longest Subarray With Sum K, Array contains -ve also",
        "links": [
          "http://bit.ly/3mNSZ9u"
        ],
        "solution": "./striver-solutions/topics/Array/longestSubarrayWithSumK2.html",
        "notes": ""
      },
      {
        "title": "2 Sum Problem",
        "links": [
          "https://bit.ly/3Iu7zMu"
        ],
        "solution": "./striver-solutions/topics/Array/twoSumProblem.html",
        "notes": ""
      },
      {
        "title": "Sort An Array of 0s, 1s and 2s",
        "links": [
          "https://bit.ly/3CsgYAa"
        ],
        "solution": "./striver-solutions/topics/Array/sortAnArrayOfOs1s2s.html",
        "notes": "optimal approach solved by using Dutch national flag algo"
      },
      {
        "title": "Majority Element I",
        "links": [
          "https://bit.ly/3GmPYTH"
        ],
        "solution": "./striver-solutions/topics/Array/majorityElementsI.html",
        "notes": ""
      },
      {
        "title": "Kadane's Algorithm | Maximum Subarray Sum | Finding and Printing",
        "links": [
          "https://bit.ly/3QhMl6j"
        ],
        "solution": "./striver-solutions/topics/Array/kadanesAlogToFindMaxSubarraySum.html",
        "notes": ""
      },
      {
        "title": "Rearrange Array Elements by Sign",
        "links": [
          "http://bit.ly/3yRrCOT"
        ],
        "solution": "./striver-solutions/topics/Array/rearrangeArrElemBySign.html",
        "notes": ""
      },
      {
        "title": "Next Greater Permutation",
        "links": [
          "https://bit.ly/3WOGkjH"
        ],
        "solution": "./striver-solutions/topics/Array/nextGreaterPermutation.html",
        "notes": ""
      },
      {
        "title": "Superior Elements",
        "links": [
          "https://bit.ly/3QiQ830"
        ],
        "solution": "./striver-solutions/topics/Array/leaderInArray.html",
        "notes": ""
      },
      {
        "title": "Longest Successive Elements",
        "links": [
          "https://bit.ly/3GiWSJP"
        ],
        "solution": "./striver-solutions/topics/Array/LongestSuccessiveElements.html",
        "notes": ""
      },
      {
        "title": "Zero Matrix",
        "links": [
          "https://bit.ly/3CukQke"
        ],
        "solution": "./striver-solutions/topics/Array/ZeroMatrix.html",
        "notes": ""
      },
      {
        "title": "Rotate The Matrix",
        "links": [
          "https://bit.ly/3Qk14gY"
        ],
        "solution": "./striver-solutions/topics/Array/rotateTheMatrix.html",
        "notes": ""
      },
      {
        "title": "Spiral Matrix",
        "links": [
          "https://bit.ly/3InYB3c"
        ],
        "solution": "./striver-solutions/topics/Array/spiralMatrix.html",
        "notes": ""
      },
      {
        "title": "Count All Subarrays With Given Sum",
        "links": [
          "http://bit.ly/3Kn10eZ"
        ],
        "solution": "./striver-solutions/topics/Array/countAllSubarrWithGivenSum.html",
        "notes": ""
      },
      {
        "title": "Print Pascal’s Triangle",
        "links": [
          "https://bit.ly/3jY4iuF"
        ],
        "solution": "./striver-solutions/topics/Array/printPascalTriangle.html",
        "notes": ""
      },
      {
        "title": "Majority Element II",
        "links": [
          "https://bit.ly/3vIsCTH"
        ],
        "solution": "./striver-solutions/topics/Array/majorityElem2.html",
        "notes": ""
      },
      {
        "title": "Three Sum",
        "links": [
          "https://bit.ly/3X34JSI"
        ],
        "solution": "./striver-solutions/topics/Array/ThreeSum.html",
        "notes": ""
      },
      {
        "title": "four Sum",
        "links": [
          "https://bit.ly/3It5SyP"
        ],
        "solution": "./striver-solutions/topics/Array/fourSum.html",
        "notes": ""
      },
      {
        "title": "Subarrays with XOR ‘K’",
        "links": [
          "https://bit.ly/3jLfElm"
        ],
        "solution": "./striver-solutions/topics/Array/subarrayWithXorK.html",
        "notes": ""
      },
      {
        "title": "Merge All Overlapping Intervals",
        "links": [
          "https://bit.ly/3ItlwtJ"
        ],
        "solution": "./striver-solutions/topics/Array/mergeOverlapIntervals.html",
        "notes": ""
      },
      {
        "title": "Merge Two Sorted Arrays Without Extra Space",
        "links": [
          "https://bit.ly/3jLQGSS"
        ],
        "solution": "./striver-solutions/topics/Array/merge2SortedArrayWOExtraSpace.html",
        "notes": ""
      },
      {
        "title": "Find the Missing and Repeating Number",
        "links": [
          "https://bit.ly/3vK0LT4"
        ],
        "solution": "./striver-solutions/topics/Array/findMissingAndRepeatingNumber.html",
        "notes": ""
      },
      {
        "title": "Reverse Pairs",
        "links": [
          "https://bit.ly/3Zj9U2L"
        ],
        "solution": "./striver-solutions/topics/Array/ReversePairs.html",
        "notes": ""
      },
      {
        "title": "Subarray With Maximum Product",
        "links": [
          "https://bit.ly/3VPdyyq"
        ],
        "solution": "./striver-solutions/topics/Array/subarrWithMaxProduct.html",
        "notes": ""
      }
    ]
  },
  {
    "id": "recursion",
    "name": "Recursion",
    "description": "Practice recursion, backtracking, and subset generation patterns.",
    "symbol": "fn",
    "problems": [
      {
        "title": "Print 1-N",
        "links": [],
        "solution": "./striver-solutions/topics/recursion_solution/print_name.html",
        "notes": "--"
      },
      {
        "title": "Parameterized and functional recursion",
        "links": [],
        "solution": "./striver-solutions/topics/recursion_solution/sum_of_N_Number.html",
        "notes": "Parameterized means we pass the extra arguments into the function to collect the results in it then when end point come we print it. Function recursion is nothing but we return the answer by function itself. E.g. return fun(n-1)+func(n-2);"
      },
      {
        "title": "Functional recursion",
        "links": [],
        "solution": "./striver-solutions/topics/recursion_solution/reverseArray_Palindrome.html",
        "notes": "--"
      },
      {
        "title": "Multiple recursion calls or Tree recursion",
        "links": [],
        "solution": "./striver-solutions/topics/recursion_solution/fibonacciSeries.html",
        "notes": "--"
      },
      {
        "title": "Print all subsequences of an array or a string",
        "links": [],
        "solution": "./striver-solutions/topics/recursion_solution/printAllSubsequences.html",
        "notes": "--"
      },
      {
        "title": "All Kind of patterns in Recursion",
        "links": [],
        "solution": "./striver-solutions/topics/recursion_solution/AllKind_PatternIn_Recursion.html",
        "notes": "so here we learn 3 type of different question could be asked in a problem, like print all or print only count or print any one."
      },
      {
        "title": "Combination Sum1",
        "links": [
          "https://leetcode.com/problems/combination-sum/description/"
        ],
        "solution": "./striver-solutions/topics/recursion_solution/combinationSum1.html",
        "notes": "--"
      },
      {
        "title": "Combination Sum2",
        "links": [
          "https://leetcode.com/problems/combination-sum-ii/description/"
        ],
        "solution": "./striver-solutions/topics/recursion_solution/combinationSum2.html",
        "notes": "2nd type of recursion, in a recursion use a for loop"
      },
      {
        "title": "Subset sum1",
        "links": [
          "https://practice.geeksforgeeks.org/problems/subset-sum-problem-1611555638/1"
        ],
        "solution": "./striver-solutions/topics/recursion_solution/subsetSum1.html",
        "notes": "You will learn overlapping of the problem so memoization is done here. Try [2, 3, 1, 1] target=4. When you will draw a tree of recursion you will get overlapping if we start recursion from the last index."
      },
      {
        "title": "Subset sum2",
        "links": [
          "https://leetcode.com/problems/subsets-ii/submissions/808067059/"
        ],
        "solution": "./striver-solutions/topics/recursion_solution/subsetSum2.html",
        "notes": "this is same question as combination sum2 but here we have to pick each combination."
      },
      {
        "title": "Print all permutation of an array",
        "links": [
          "https://leetcode.com/problems/permutations/description/"
        ],
        "solution": "./striver-solutions/topics/recursion_solution/printAllPermutation.html",
        "notes": "--"
      },
      {
        "title": "N Queens",
        "links": [
          "https://leetcode.com/problems/n-queens/"
        ],
        "solution": "./striver-solutions/topics/recursion_solution/NQueen.html",
        "notes": "Lower diagonal trick: start with filling 0 from the last row and first col, then to guess what could be the formula see the middle diagonal. Middle diagonal for lower diagonal case will be the n-1 number."
      },
      {
        "title": "Sudoku",
        "links": [
          "https://leetcode.com/problems/sudoku-solver/"
        ],
        "solution": "./striver-solutions/topics/recursion_solution/Sudoku.html",
        "notes": "--"
      },
      {
        "title": "M-Coloring Problem",
        "links": [
          "https://practice.geeksforgeeks.org/problems/m-coloring-problem-1587115620/1"
        ],
        "solution": "./striver-solutions/topics/recursion_solution/MColoring.html",
        "notes": "--"
      },
      {
        "title": "Palindrome Partitioning",
        "links": [
          "https://leetcode.com/problems/palindrome-partitioning/"
        ],
        "solution": "./striver-solutions/topics/recursion_solution/palindromePartitioning.html",
        "notes": "--"
      },
      {
        "title": "Rat in a Maze Problem - I",
        "links": [
          "https://practice.geeksforgeeks.org/problems/rat-in-a-maze-problem/1"
        ],
        "solution": "./striver-solutions/topics/recursion_solution/RatInMaze1.html",
        "notes": "--"
      },
      {
        "title": "Permutation Sequence",
        "links": [
          "https://leetcode.com/problems/permutation-sequence/description/"
        ],
        "solution": "./striver-solutions/topics/recursion_solution/permutationSequence.html",
        "notes": "--"
      },
      {
        "title": "Merge sort",
        "links": [],
        "solution": "./striver-solutions/topics/recursion_solution/mergeSort.html",
        "notes": "--"
      },
      {
        "title": "Count inversion in an array",
        "links": [
          "https://www.codingninjas.com/codestudio/problems/number-of-inversions_6840276?utm_source=youtube&utm_medium=affiliate&utm_campaign=striver_Arrayproblems"
        ],
        "solution": "./striver-solutions/topics/recursion_solution/CountInversion.html",
        "notes": "--"
      }
    ]
  },
  {
    "id": "dynamic-programming",
    "name": "Dynamic Programming",
    "description": "Learn state transitions from one-dimensional to advanced DP.",
    "symbol": "dp",
    "problems": [
      {
        "title": "Count Ways To Reach The N-th Stairs",
        "links": [
          "https://www.naukri.com/code360/problems/count-ways-to-reach-nth-stairs_798650?source=youtube&campaign=striver_dp_videos&utm_source=youtube&utm_medium=affiliate&utm_campaign=striver_dp_videos&leftPanelTabValue=PROBLEM"
        ],
        "solution": "./striver-solutions/topics/DP_solution/NStair.html",
        "notes": "The expression 1e9+7 represents the number 1,000,000,007. Its commonly used in programming as a prime number close to (10^9) for computations involving large numbers. This helps prevent integer overflow and ensures that results fit within the range of standard integer types."
      },
      {
        "title": "Frog jump",
        "links": [
          "https://www.naukri.com/code360/problems/frog-jump_3621012?source=youtube&campaign=striver_dp_videos&utm_source=youtube&utm_medium=affiliate&utm_campaign=striver_dp_videos"
        ],
        "solution": "./striver-solutions/topics/DP_solution/FrogJump.html",
        "notes": ""
      },
      {
        "title": "Frog Jump with K Distance",
        "links": [
          "https://atcoder.jp/contests/dp/tasks/dp_b"
        ],
        "solution": "./striver-solutions/topics/DP_solution/FrogJumpWithKDistance.html",
        "notes": "--"
      },
      {
        "title": "Maximum Sum of Non-Adjacent Elements",
        "links": [
          "https://bit.ly/3PURfqU"
        ],
        "solution": "./striver-solutions/topics/DP_solution/MaxSumOfNonAdjcElems.html",
        "notes": "--"
      },
      {
        "title": "House Robber II",
        "links": [
          "https://bit.ly/49vceYm"
        ],
        "solution": "./striver-solutions/topics/DP_solution/HouserRobber2.html",
        "notes": "This question is similar to Maximum Sum of Non-Adjacent Elements only modification to handle cirle neighboorhood so it is handle by taking max of 2 ans in first ans not considering 0th element then in second ans not considering last the element. Reason is as mentioned in the question 1st and last neighbour are adjacent, so in the ans either 0th element wont come or last element wont come thats why we eleminate either 0th element or last element this question is only solved in tabulation mode since similar question to Maximum Sum of Non-Adjacent Elements."
      },
      {
        "title": "Ninjas Training ***",
        "links": [
          "https://bit.ly/49w8Lsr"
        ],
        "solution": "./striver-solutions/topics/DP_solution/ninjaTraining.html",
        "notes": "--"
      },
      {
        "title": "Unique paths",
        "links": [
          "https://bit.ly/3TOpWzq"
        ],
        "solution": "./striver-solutions/topics/DP_solution/UniquePath.html",
        "notes": "This question has been solved in two way, coz in first way TC was not sufficient."
      },
      {
        "title": "Unique Paths 2 | DP on Grid with Maze Obstacles",
        "links": [
          "https://bit.ly/4dfsUG7"
        ],
        "solution": "./striver-solutions/topics/DP_solution/uniquePath2.html",
        "notes": "--"
      },
      {
        "title": "Minimum Path Sum in Grid",
        "links": [
          "https://bit.ly/3UgrtyN"
        ],
        "solution": "./striver-solutions/topics/DP_solution/MinPathSumInGrid.html",
        "notes": ""
      },
      {
        "title": "Triangle | Fixed Starting Point and Variable Ending Point",
        "links": [
          "https://bit.ly/3UxeREz"
        ],
        "solution": "./striver-solutions/topics/DP_solution/triangle.html",
        "notes": "--"
      },
      {
        "title": "Triangle | Fixed Starting Point and Variable Ending Point",
        "links": [
          "https://bit.ly/3UxeREz"
        ],
        "solution": "./striver-solutions/topics/DP_solution/triangle.html",
        "notes": "--"
      },
      {
        "title": "Minimum/Maximum Falling Path Sum",
        "links": [
          "https://bit.ly/3xWqtbp"
        ],
        "solution": "./striver-solutions/topics/DP_solution/MaxMinFallingPath.html",
        "notes": "--"
      },
      {
        "title": "Cherry Pickup II | 3D DP",
        "links": [
          "https://bit.ly/3QnEwNL"
        ],
        "solution": "./striver-solutions/topics/DP_solution/CherryPickup2.html",
        "notes": "This is a 3D DP problem, tabulation and space optimization is not done yet will solve it later."
      },
      {
        "title": "Subset Sum Equals to Target",
        "links": [
          "https://bit.ly/3ukNmRZ"
        ],
        "solution": "./striver-solutions/topics/DP_solution/subsetSumEqToTarget.html",
        "notes": "Tabulation is not clear fully, space optimization is also not clear"
      },
      {
        "title": "Partition Equal Subset Sum",
        "links": [
          "https://bit.ly/34iIIsH"
        ],
        "solution": "./striver-solutions/topics/DP_solution/partitionEqualSubsetSum.html",
        "notes": "this question is similar to Subset Sum Equals to Target, but here target just changed to totalSum/2 to for the 1st subset and for the 2nd subset other totalSum/2 would be the ans."
      },
      {
        "title": "Partition A Set Into Two Subsets With Minimum Absolute Sum Difference",
        "links": [
          "https://bit.ly/3t62bqQ"
        ],
        "solution": "./striver-solutions/topics/DP_solution/PartitionIn2SubsetWithMinDiff.html",
        "notes": "this question is similar to Subset Sum Equals to Target, but here target just changed to totalSum/2 to for the 1st subset and for the 2nd subset other totalSum/2 would be the ans."
      },
      {
        "title": "Counts Subsets with Sum K",
        "links": [
          "https://bit.ly/3B5JBkU"
        ],
        "solution": "./striver-solutions/topics/DP_solution/countOfSubsetSumEqToK.html",
        "notes": ""
      },
      {
        "title": "Count Partitions With Given Difference",
        "links": [
          "https://bit.ly/3r8mG5b"
        ],
        "solution": "./striver-solutions/topics/DP_solution/countPartitionWithGivenDiff.html",
        "notes": ""
      },
      {
        "title": "Knapsack",
        "links": [
          "https://bit.ly/3KHpP3v"
        ],
        "solution": "./striver-solutions/topics/DP_solution/Knapsack.html",
        "notes": "In this question have learned more about space optimization, recommended to check the code comments if not understood then check in corresponding video."
      },
      {
        "title": "Minimum Coins",
        "links": [
          "https://bit.ly/3HJTeIl"
        ],
        "solution": "./striver-solutions/topics/DP_solution/MinimumCoins.html",
        "notes": ""
      },
      {
        "title": "Target Sum",
        "links": [
          "https://bit.ly/3swy5uL"
        ],
        "solution": "./striver-solutions/topics/DP_solution/targetSum.html",
        "notes": "this question is exact similar to Question 18: Count Partitions With Given Difference. In this question just changed the language."
      },
      {
        "title": "Coin Change 2",
        "links": [
          "https://bit.ly/33Kd8o2"
        ],
        "solution": "./striver-solutions/topics/DP_solution/coinChange2.html",
        "notes": ""
      },
      {
        "title": "Unbounded Knapsack",
        "links": [
          "https://bit.ly/3IvPdXS"
        ],
        "solution": "./striver-solutions/topics/DP_solution/unboundedKnapsack.html",
        "notes": ""
      },
      {
        "title": "Rod Cutting Problem",
        "links": [
          "https://bit.ly/3H10kYJ"
        ],
        "solution": "./striver-solutions/topics/DP_solution/RodCuttingProblem.html",
        "notes": ""
      },
      {
        "title": "Longest Common Subsequence",
        "links": [
          "https://bit.ly/3pvkqUd"
        ],
        "solution": "./striver-solutions/topics/DP_solution/LongestCommonSubsequence.html",
        "notes": "In this code we done right shift of the index.. Read the code for reason or else check its video"
      },
      {
        "title": "Print Longest Common Subsequence",
        "links": [
          "https://www.naukri.com/code360/problems/print-longest-common-subsequence_8416383"
        ],
        "solution": "./striver-solutions/topics/DP_solution/PrintLongestCommonSubsequence.html",
        "notes": "1st we make the dp matrix then in matrix if we look the last index dp[n][m] there we will get the max lenght of the ans. Now we have to make string. So we backtrace the matrix from the last index and make the longest common subsequence string."
      },
      {
        "title": "Longest Common Substring",
        "links": [
          "https://bit.ly/3H2M3KS"
        ],
        "solution": "./striver-solutions/topics/DP_solution/longestCommonSubscript.html",
        "notes": ""
      },
      {
        "title": "Longest Palindromic Subsequence",
        "links": [
          "https://www.naukri.com/code360/problems/longest-palindromic-subsequence_842787?leftPanelTabValue=PROBLEM"
        ],
        "solution": "./striver-solutions/topics/DP_solution/longestPalindromicSubsequence.html",
        "notes": "In this question has given only 1 string. For which we have to find out the longest palindromic subsequence. For a solution we make another string by just making reverse of the given string and treted this question similar as LONGEST COMMON SUBSEQUENCE. Go to the video if not understood."
      },
      {
        "title": "Minimum insertions to make a string palindrome",
        "links": [
          "https://bit.ly/3H2ZtGP"
        ],
        "solution": "./striver-solutions/topics/DP_solution/MinInsertToMakeStrPalindrome.html",
        "notes": "This question is similar to - Question 28: Longest Palindromic Subsequence. With small addition like str.length - longestPalindromicSubsequence"
      },
      {
        "title": "Minimum Insertions/Deletions to Convert String A to String B",
        "links": [
          "https://bit.ly/3pya8CP"
        ],
        "solution": "./striver-solutions/topics/DP_solution/MinInsert_DeletionToMakeStr1toStr2.html",
        "notes": "This question is similar to - Question 28: Longest Palindromic Subsequence. With small addition like: for deletion of char str1.length - longestPalindromicSubsequence for addition of char str2.length - longestPalindromicSubsequence"
      },
      {
        "title": "Shortest Common Supersequence",
        "links": [
          "https://bit.ly/3vEYKce"
        ],
        "solution": "./striver-solutions/topics/DP_solution/ShortestCommonSupersequence.html",
        "notes": "This problem is similar to Question 26: Print Longest Common Subsequence, with small addition to form a super string. Check the image in the solution page."
      },
      {
        "title": "Distinct Subsequences",
        "links": [
          "https://bit.ly/3nZNxy7"
        ],
        "solution": "./striver-solutions/topics/DP_solution/DistinctSubsequences.html",
        "notes": ""
      },
      {
        "title": "Edit Distance",
        "links": [
          "https://bit.ly/3HcTJdy"
        ],
        "solution": "./striver-solutions/topics/DP_solution/EditDistance.html",
        "notes": ""
      },
      {
        "title": "Wildcard Matching",
        "links": [
          "https://bit.ly/3vEYKce"
        ],
        "solution": "./striver-solutions/topics/DP_solution/WildcardMatching.html",
        "notes": ""
      },
      {
        "title": "Best Time to Buy and Sell Stock",
        "links": [
          "https://bit.ly/3rN7GIL"
        ],
        "solution": "./striver-solutions/topics/DP_solution/BestTimetoBuy_SellStock.html",
        "notes": ""
      },
      {
        "title": "Buy and Sell Stock - II",
        "links": [
          "https://bit.ly/3nYO17H"
        ],
        "solution": "./striver-solutions/topics/DP_solution/BuyAndSell2.html",
        "notes": ""
      },
      {
        "title": "Buy and Sell Stock - III",
        "links": [
          "https://bit.ly/3rLHkqQ"
        ],
        "solution": "./striver-solutions/topics/DP_solution/BuyAndSell3.html",
        "notes": ""
      },
      {
        "title": "Buy and Sell Stock - IV",
        "links": [
          "https://bit.ly/346R72e"
        ],
        "solution": "./striver-solutions/topics/DP_solution/BuyAndSell4.html",
        "notes": "This question is solved using total no of transaction as well"
      },
      {
        "title": "Buy and Sell Stocks With Cooldown",
        "links": [
          "https://bit.ly/3tZsYWA"
        ],
        "solution": "./striver-solutions/topics/DP_solution/BuyAndSellWithCooldown.html",
        "notes": ""
      },
      {
        "title": "Buy and Sell Stocks With Transaction Fee",
        "links": [
          "https://bit.ly/3nZucNH"
        ],
        "solution": "./striver-solutions/topics/DP_solution/BuyAndSellWithFee.html",
        "notes": "Similar to Buy and Sell Stock - II, only fee added here"
      },
      {
        "title": "Longest Increasing Subsequence",
        "links": [
          "https://bit.ly/3rVoIoq"
        ],
        "solution": "./striver-solutions/topics/DP_solution/LongestIncresSubsequence.html",
        "notes": "All test cases not solved, TLE coming since TC of all solution given is n^2"
      },
      {
        "title": "( @ @ ) Printing Longest Increasing Subsequence",
        "links": [
          "https://bit.ly/3nYO17H"
        ],
        "solution": "./striver-solutions/topics/DP_solution/PrintLongestIncresSubsequence.html",
        "notes": "This is tricky problem, first try to solve it on white board..."
      },
      {
        "title": "Largest Divisible Subset",
        "links": [
          "https://bit.ly/3rON1Ef"
        ],
        "solution": "./striver-solutions/topics/DP_solution/PrintLargestDivisibleSubset.html",
        "notes": ""
      },
      {
        "title": "Longest String Chain",
        "links": [
          "https://bit.ly/3KHsl9J"
        ],
        "solution": "./striver-solutions/topics/DP_solution/LongestStringChain.html",
        "notes": "This is almost similar to LIS problem, but you have to match is with Tabulation method. To understand this problem check the image and notes on this mention on solution page."
      },
      {
        "title": "Longest Bitonic Subsequence",
        "links": [
          "https://bit.ly/3r4o1JB"
        ],
        "solution": "./striver-solutions/topics/DP_solution/LongestBitonicSubsequence.html",
        "notes": "What is bitonic? first increasing then decresing sequence is called the bitonic. this will be solve like first we calculate the LIS from left then right, then add the dp1[i]+dp2[i]-1 where i:0-->n-1. Check its image in solution"
      },
      {
        "title": "** Number of Longest Increasing Subsequence",
        "links": [
          "https://bit.ly/3fTRGiz"
        ],
        "solution": "./striver-solutions/topics/DP_solution/NumberofLongestIncreasingSubsequence.html",
        "notes": ""
      },
      {
        "title": "------Partition DP---------",
        "links": [],
        "solution": "./striver-solutions/topics/DP_solution/partitionDP.html",
        "notes": ""
      },
      {
        "title": "🔥 Matrix Chain Multiplication",
        "links": [
          "https://bit.ly/3nXqfce"
        ],
        "solution": "./striver-solutions/topics/DP_solution/MatrixChainMultiplication.html",
        "notes": ""
      },
      {
        "title": "(@ @) Minimum Cost to Cut the Stick",
        "links": [
          "https://bit.ly/3rWLMnC"
        ],
        "solution": "./striver-solutions/topics/DP_solution/MinCostToCutStick.html",
        "notes": ""
      },
      {
        "title": "Burst Balloons",
        "links": [
          "https://bit.ly/3Kgck9N"
        ],
        "solution": "./striver-solutions/topics/DP_solution/BurstBalloons.html",
        "notes": ""
      },
      {
        "title": "Evaluate Boolean Expression to True | Partition DP",
        "links": [
          "https://bit.ly/32tAMUW"
        ],
        "solution": "./striver-solutions/topics/DP_solution/EvaluateBooleanExprToTrue.html",
        "notes": "https://takeuforward.org/data-structure/evaluate-boolean-expression-to-true-partition-dp-dp-52/"
      },
      {
        "title": "Palindrome Partitioning - II",
        "links": [
          "https://bit.ly/3jNRzqX"
        ],
        "solution": "./striver-solutions/topics/DP_solution/PalindromePartitioning2.html",
        "notes": ""
      },
      {
        "title": "Partition Array for Maximum Sum",
        "links": [
          "https://www.naukri.com/code360/problems/partition-array-for-maximum-sum_3755255"
        ],
        "solution": "./striver-solutions/topics/DP_solution/PartitionArrforMaxSum.html",
        "notes": ""
      },
      {
        "title": "Maximum Rectangle Area with all 1's",
        "links": [
          "https://bit.ly/33HFz61"
        ],
        "solution": "./striver-solutions/topics/StackNQueue/MaximalRectangle.html",
        "notes": "We will solve this problem when we will learn stack and queue DSA, in max area of rectangle from histogram problem this question come."
      },
      {
        "title": "Count Square Submatrices with All Ones",
        "links": [
          "https://bit.ly/3tYAUY7"
        ],
        "solution": "./striver-solutions/topics/DP_solution/CountSquareInMatrix.html",
        "notes": ""
      }
    ]
  },
  {
    "id": "linked-lists",
    "name": "Linked Lists",
    "description": "Work through singly, doubly, and linked-list manipulation problems.",
    "symbol": "LL",
    "problems": [
      {
        "title": "Linked list program",
        "links": [],
        "solution": "./striver-solutions/topics/Linkedlist/linkedList.html",
        "notes": ""
      },
      {
        "title": "Double Linked list program",
        "links": [],
        "solution": "./striver-solutions/topics/Linkedlist/DoublelinkedList.html",
        "notes": ""
      },
      {
        "title": "Delete Node In A Linked List",
        "links": [
          "https://www.naukri.com/code360/problems/delete-node-in-a-linked-list_1105578?leftPanelTabValue=PROBLEM"
        ],
        "solution": "./striver-solutions/topics/Linkedlist/deleteNode.html",
        "notes": "In this problem you will be given only single node that needs to be deleted and no other node will be given."
      },
      {
        "title": "Convert Array into a single linklist",
        "links": [],
        "solution": "./striver-solutions/topics/Linkedlist/convertArrayToSingleLL.html",
        "notes": ""
      },
      {
        "title": "Convert Array into a double linklist",
        "links": [],
        "solution": "./striver-solutions/topics/Linkedlist/convertArrayToDoubleLL.html",
        "notes": ""
      },
      {
        "title": "Reverse Double link list",
        "links": [
          "https://tinyurl.com/mw45vuf6"
        ],
        "solution": "./striver-solutions/topics/Linkedlist/revereseDoubleLL.html",
        "notes": "Use the swapping algo here, just difference here is instead of 2 variable to swap here next and prev to swap"
      },
      {
        "title": "Reverse link list",
        "links": [
          "https://tinyurl.com/2ajt9262"
        ],
        "solution": "./striver-solutions/topics/Linkedlist/revereseLL.html",
        "notes": ""
      },
      {
        "title": "Add 2 numbers in LinkedList",
        "links": [
          "https://www.naukri.com/code360/problems/reverse-linked-list_920513?leftPanelTabValue=PROBLEM"
        ],
        "solution": "./striver-solutions/topics/Linkedlist/Add2NumberInLL.html",
        "notes": ""
      },
      {
        "title": "Odd Even Linked List",
        "links": [
          "https://tinyurl.com/47fu86tm"
        ],
        "solution": "./striver-solutions/topics/Linkedlist/OddEvenLinkedList.html",
        "notes": ""
      },
      {
        "title": "Sort linked list of 0s 1s 2s",
        "links": [
          "https://tinyurl.com/47fu86tm"
        ],
        "solution": "./striver-solutions/topics/Linkedlist/SortLLOf012.html",
        "notes": ""
      },
      {
        "title": "Remove Nth Node from the end of the LinkedList",
        "links": [
          "https://tinyurl.com/4txecfpz"
        ],
        "solution": "./striver-solutions/topics/Linkedlist/deleteNthNodefromLast.html",
        "notes": "To solve this problem, fast and slow pointer algo is used. Firs move the fast pointer by N value, then point slow to head and move both slow and fast pointer until fast->next reach to null"
      },
      {
        "title": "Check ll is palindrome or not",
        "links": [
          "https://tinyurl.com/2p869csv"
        ],
        "solution": "./striver-solutions/topics/Linkedlist/checkPalindromeLL.html",
        "notes": "Basic algo is first we figure out the middle of the linkedlist using fast and slow pointer algo, the will reverese the second half of the linkedlist then compare the ll, then revert the 2nd half of ll which was reversed"
      },
      {
        "title": "Add 1 to a number represented by LinkedList",
        "links": [
          "https://tinyurl.com/3hrjsb36"
        ],
        "solution": "./striver-solutions/topics/Linkedlist/add1ToANumberRepresentedByLL.html",
        "notes": "Basic algo is first we figure out the middle of the linkedlist using fast and slow pointer algo, the will reverese the second half of the linkedlist then compare the ll, then revert the 2nd half of ll which was reversed"
      },
      {
        "title": "Find the intersection point of Y LinkedList",
        "links": [
          "https://tinyurl.com/yc344rnt"
        ],
        "solution": "./striver-solutions/topics/Linkedlist/YintersectionLL.html",
        "notes": "Naive approach: store all elment node 1st ll in hash map, then start store 2nd ll element node in same hash map, if encounter same node then return that node else return null."
      },
      {
        "title": "Find middle node of the LinkedList",
        "links": [
          "https://tinyurl.com/ykfyj5cd"
        ],
        "solution": "./striver-solutions/topics/Linkedlist/middleNode.html",
        "notes": "Naive approach: find the lend of ll then divide by 2, then traverse to that mid node element"
      },
      {
        "title": "Detect a loop or cycle in LinkedList",
        "links": [
          "https://tinyurl.com/3rxwup5c"
        ],
        "solution": "./striver-solutions/topics/Linkedlist/detectCircleInLL.html",
        "notes": "people could ask, why fastPointer will collied with slow pointer if loop is there in LL, why not fast pointer cross over slow pointer? check striver video he explained it."
      },
      {
        "title": "Find the length of the Loop in LinkedList",
        "links": [
          "https://tinyurl.com/5n78kcda"
        ],
        "solution": "./striver-solutions/topics/Linkedlist/lengthOfLoopInLL.html",
        "notes": ""
      },
      {
        "title": "Delete middle node of the LL",
        "links": [
          "https://tinyurl.com/4c5a64xv"
        ],
        "solution": "./striver-solutions/topics/Linkedlist/deleteMiddleNode.html",
        "notes": ""
      },
      {
        "title": "Detect the starting node of the Loop in LL",
        "links": [
          "https://tinyurl.com/4c5a64xv"
        ],
        "solution": "./striver-solutions/topics/Linkedlist/detectStartingNodeInLL.html",
        "notes": "Check striver video to know why slow and fast will collied at the starting of the loop in 2nd step."
      },
      {
        "title": "Delete all occurrences of a Key in DLL",
        "links": [
          "https://tinyurl.com/yc7znssk"
        ],
        "solution": "./striver-solutions/topics/Linkedlist/delAllOccurencesOfKeyInDLL.html",
        "notes": ""
      },
      {
        "title": "Find all Pairs with given Sum in DLL",
        "links": [
          "https://tinyurl.com/y4xca7e5"
        ],
        "solution": "./striver-solutions/topics/Linkedlist/findPairWithGivenSuminDLL.html",
        "notes": ""
      },
      {
        "title": "Remove duplicates from sorted DLL",
        "links": [
          "https://tinyurl.com/5n8ndcuu"
        ],
        "solution": "./striver-solutions/topics/Linkedlist/RemduplicatesfrmsortedDLL.html",
        "notes": ""
      },
      {
        "title": "*** Reverse Nodes in K Group Size of LinkedList",
        "links": [
          "https://tinyurl.com/4dbz8fnn"
        ],
        "solution": "./striver-solutions/topics/Linkedlist/ReverseNodeInKGroupSize.html",
        "notes": ""
      },
      {
        "title": "Rotate a LinkedList",
        "links": [
          "https://leetcode.com/problems/rotate-list/description/?submissionId=657895105"
        ],
        "solution": "./striver-solutions/topics/Linkedlist/RotateLL.html",
        "notes": ""
      },
      {
        "title": "Merge two sorted Linked Lists",
        "links": [
          "https://bit.ly/3vjuaGQ"
        ],
        "solution": "./striver-solutions/topics/Linkedlist/merge2SortedLL.html",
        "notes": ""
      },
      {
        "title": "Flattening a LinkedList",
        "links": [
          "https://tinyurl.com/2p9ns48e"
        ],
        "solution": "./striver-solutions/topics/Linkedlist/FlatteningLinkedList.html",
        "notes": ""
      },
      {
        "title": "***Merge K Sorted Lists",
        "links": [
          "https://www.naukri.com/code360/problems/merge-k-sorted-lists_992772"
        ],
        "solution": "./striver-solutions/topics/Linkedlist/mergeKSortedLL.html",
        "notes": ""
      },
      {
        "title": "Sort a Linked List | Merge Sort and Brute Force",
        "links": [
          "https://bit.ly/4aSKrTF"
        ],
        "solution": "./striver-solutions/topics/Linkedlist/sortLL.html",
        "notes": ""
      },
      {
        "title": "Clone a LinkedList with Next and Random Pointers | Copy List with Random Pointers",
        "links": [
          "https://tinyurl.com/ytkm6xuz"
        ],
        "solution": "./striver-solutions/topics/Linkedlist/cloneLLWithNextAndRandomPointers.html",
        "notes": "It's a 3 step process to solve this problem"
      },
      {
        "title": "Design a Browser History",
        "links": [
          "https://bit.ly/3tHiY6k"
        ],
        "solution": "./striver-solutions/topics/Linkedlist/DesignABrowserHistory.html",
        "notes": ""
      }
    ]
  },
  {
    "id": "trees",
    "name": "Trees",
    "description": "Cover binary trees, binary search trees, traversals, and tree views.",
    "symbol": "TR",
    "problems": [
      {
        "title": "Basic Tree Program",
        "links": [],
        "solution": "./striver-solutions/topics/Tree/tree.html",
        "notes": ""
      },
      {
        "title": "preOrder inOrder postOrder in 1 go using iterative approach",
        "links": [],
        "solution": "./striver-solutions/topics/Tree/iterateApproachToTraverseTree.html",
        "notes": ""
      },
      {
        "title": "Check for Balanced Binary Tree",
        "links": [
          "https://leetcode.com/problems/balanced-binary-tree/description"
        ],
        "solution": "./striver-solutions/topics/Tree/checkBalanceBinaryTree.html",
        "notes": ""
      },
      {
        "title": "Diameter of binary tree",
        "links": [
          "https://leetcode.com/problems/diameter-of-binary-tree/description/"
        ],
        "solution": "./striver-solutions/topics/Tree/diameter.html",
        "notes": ""
      },
      {
        "title": "Maximum Path Sum in Binary Tree",
        "links": [
          "https://leetcode.com/problems/binary-tree-maximum-path-sum/description/"
        ],
        "solution": "./striver-solutions/topics/Tree/maxPathSum.html",
        "notes": ""
      },
      {
        "title": "Check it two trees are Identical or Not",
        "links": [
          "https://leetcode.com/problems/same-tree/description/"
        ],
        "solution": "./striver-solutions/topics/Tree/twoIdenticalTree.html",
        "notes": "just do the any traversal in both tree at the same time."
      },
      {
        "title": "Zig-Zag or Spiral Traversal in Binary Tree",
        "links": [
          "https://leetcode.com/problems/binary-tree-zigzag-level-order-traversal/description/"
        ],
        "solution": "./striver-solutions/topics/Tree/zigzagTraversal.html",
        "notes": "do a level order traversal with a flag help"
      },
      {
        "title": "Boundary Traversal in Binary Tree",
        "links": [
          "https://www.naukri.com/code360/problems/boundary-traversal_790725"
        ],
        "solution": "./striver-solutions/topics/Tree/boundaryTraversal.html",
        "notes": "Check algo image in solution"
      },
      {
        "title": "Vertical Order Traversal of Binary Tree",
        "links": [
          "https://leetcode.com/problems/vertical-order-traversal-of-a-binary-tree/description/"
        ],
        "solution": "./striver-solutions/topics/Tree/verticalTraversal.html",
        "notes": ""
      },
      {
        "title": "Top View of Binary Tree",
        "links": [
          "https://www.geeksforgeeks.org/problems/top-view-of-binary-tree/1"
        ],
        "solution": "./striver-solutions/topics/Tree/topViewOfBT.html",
        "notes": ""
      },
      {
        "title": "Bottom View of Binary Tree",
        "links": [
          "https://www.geeksforgeeks.org/problems/bottom-view-of-binary-tree/1"
        ],
        "solution": "./striver-solutions/topics/Tree/BottomViewOfBT.html",
        "notes": ""
      },
      {
        "title": "Right/Left View of Binary Tree",
        "links": [
          "https://leetcode.com/problems/binary-tree-right-side-view/description/"
        ],
        "solution": "./striver-solutions/topics/Tree/rightSideViewBT.html",
        "notes": ""
      },
      {
        "title": "Check for Symmetrical Binary Trees",
        "links": [
          "https://www.geeksforgeeks.org/problems/symmetric-tree/1"
        ],
        "solution": "./striver-solutions/topics/Tree/SymmetricalBT.html",
        "notes": "Symmetrical Binary Trees is when we part BT in 2 part from middle of it them mirror of it should be same."
      },
      {
        "title": "Print Root to Node Path in Binary Tree",
        "links": [
          "https://takeuforward.org/plus/dsa/problems/print-root-to-note-path-in-bt"
        ],
        "solution": "./striver-solutions/topics/Tree/printRootToNodePathInBT.html",
        "notes": ""
      },
      {
        "title": "Lowest Common Ancestor in Binary Tree",
        "links": [
          "https://leetcode.com/problems/lowest-common-ancestor-of-a-binary-tree/description/"
        ],
        "solution": "./striver-solutions/topics/Tree/lowestCommanAncestorInBT.html",
        "notes": ""
      },
      {
        "title": "Maximum Width of Binary Tree",
        "links": [
          "https://leetcode.com/problems/maximum-width-of-binary-tree/description/"
        ],
        "solution": "./striver-solutions/topics/Tree/maximumWidthOfBinaryTree.html",
        "notes": "Maximum Width of Binary Tree means, on the same level max number of nodes could exists"
      },
      {
        "title": "Children Sum Property in Binary Tree",
        "links": [
          "https://www.naukri.com/code360/problems/childrensumproperty_790723?leftPanelTabValue=PROBLEM"
        ],
        "solution": "./striver-solutions/topics/Tree/childrenSumPropertyBT.html",
        "notes": ""
      },
      {
        "title": "Print all the Nodes at a distance of K in Binary Tree",
        "links": [
          "https://leetcode.com/problems/all-nodes-distance-k-in-binary-tree/description/"
        ],
        "solution": "./striver-solutions/topics/Tree/printAllNodesAtKDistanceInBT.html",
        "notes": ""
      },
      {
        "title": "Minimum time taken to BURN the Binary Tree from a Node",
        "links": [
          "https://www.geeksforgeeks.org/problems/burning-tree/1?itm_source=geeksforgeeks&itm_medium=article&itm_campaign=practice_card"
        ],
        "solution": "./striver-solutions/topics/Tree/burningTree.html",
        "notes": ""
      },
      {
        "title": "Count total Nodes in a COMPLETE Binary Tree",
        "links": [
          "https://leetcode.com/problems/count-complete-tree-nodes/description"
        ],
        "solution": "./striver-solutions/topics/Tree/countTotalNodesInCBT.html",
        "notes": ""
      },
      {
        "title": "Construct a Binary Tree from Preorder and Postorder Traversal",
        "links": [
          "https://leetcode.com/problems/construct-binary-tree-from-preorder-and-postorder-traversal/description"
        ],
        "solution": "./striver-solutions/topics/Tree/constructBTusingPostPreOrder.html",
        "notes": ""
      },
      {
        "title": "Construct a Binary Tree from Preorder and Inorder Traversal",
        "links": [
          "https://leetcode.com/problems/construct-binary-tree-from-preorder-and-inorder-traversal/description/"
        ],
        "solution": "./striver-solutions/topics/Tree/ConstructAUniqueBTFromPreOrderInorder.html",
        "notes": ""
      },
      {
        "title": "Construct a Binary Tree from Postorder and Inorder Traversal",
        "links": [
          "https://leetcode.com/problems/construct-binary-tree-from-inorder-and-postorder-traversal/submissions/1331447809/"
        ],
        "solution": "./striver-solutions/topics/Tree/ConstructAUniqueBTFromPostOrderInorder.html",
        "notes": ""
      },
      {
        "title": "Serialize and De-serialize Binary Tree",
        "links": [
          "https://leetcode.com/problems/serialize-and-deserialize-binary-tree/"
        ],
        "solution": "./striver-solutions/topics/Tree/serializeNdeserializeBT.html",
        "notes": ""
      },
      {
        "title": "Morris Traversal | Preorder | Inorder",
        "links": [
          "https://leetcode.com/problems/binary-tree-inorder-traversal"
        ],
        "solution": "./striver-solutions/topics/Tree/morrisTraversal.html",
        "notes": ""
      },
      {
        "title": "Flatten a Binary Tree to Linked List | 3 Approaches",
        "links": [
          "https://leetcode.com/problems/flatten-binary-tree-to-linked-list/description/"
        ],
        "solution": "./striver-solutions/topics/Tree/flattensBT.html",
        "notes": ""
      },
      {
        "title": "Ceil & Floor value of BST",
        "links": [
          "https://www.geeksforgeeks.org/problems/implementing-ceil-in-bst/1 https://www.geeksforgeeks.org/problems/floor-in-bst/0"
        ],
        "solution": "./striver-solutions/topics/Tree/Ceil_FloorBST.html",
        "notes": ""
      },
      {
        "title": "Insert a node in BST",
        "links": [
          "https://leetcode.com/problems/insert-into-a-binary-search-tree/description/"
        ],
        "solution": "./striver-solutions/topics/Tree/insertNodeInBST.html",
        "notes": ""
      },
      {
        "title": "Delete a Node in Binary Search Tree",
        "links": [
          "https://leetcode.com/problems/delete-node-in-a-bst/description/"
        ],
        "solution": "./striver-solutions/topics/Tree/deleteANodeInBST.html",
        "notes": ""
      },
      {
        "title": "K-th Smallest/Largest Element in BST",
        "links": [
          "https://leetcode.com/problems/kth-smallest-element-in-a-bst/"
        ],
        "solution": "./striver-solutions/topics/Tree/KthSmallestElementInBST.html",
        "notes": "We will solver this problem using Morris inorder traversal Since Morris inorder traversal takes only BigO(N) TC, and BigO(1) SC Inorder traversal with BST will always be sorted Instead of vector we can take the counter"
      },
      {
        "title": "Check if a tree is a BST or BT | Validate a BST",
        "links": [
          "https://leetcode.com/problems/validate-binary-search-tree/"
        ],
        "solution": "./striver-solutions/topics/Tree/validateBST.html",
        "notes": "Algo: we will do inoder traversal, and we will pass the range for each node where that node should be fall in the range of that range."
      },
      {
        "title": "LCA in Binary Search Tree",
        "links": [
          "https://leetcode.com/problems/lowest-common-ancestor-of-a-binary-search-tree/description/"
        ],
        "solution": "./striver-solutions/topics/Tree/LCAofBST.html",
        "notes": ""
      },
      {
        "title": "Lowest Common Ancestor in Binary Tree",
        "links": [
          "https://leetcode.com/problems/lowest-common-ancestor-of-a-binary-tree/"
        ],
        "solution": "./striver-solutions/topics/Tree/LCAofBT.html",
        "notes": ""
      },
      {
        "title": "Construct a BST from a preorder traversal",
        "links": [
          "https://leetcode.com/problems/construct-binary-search-tree-from-preorder-traversal/"
        ],
        "solution": "./striver-solutions/topics/Tree/constructABSTFromPreorder.html",
        "notes": ""
      },
      {
        "title": "Inorder Successor/Predecessor in BST",
        "links": [
          "https://www.geeksforgeeks.org/problems/predecessor-and-successor/1"
        ],
        "solution": "./striver-solutions/topics/Tree/InorderSuccessorPredessorInBST.html",
        "notes": ""
      },
      {
        "title": "Binary Search Tree Iterator | BST | O(H) Space",
        "links": [
          "https://leetcode.com/problems/binary-search-tree-iterator/"
        ],
        "solution": "./striver-solutions/topics/Tree/BSTIterator.html",
        "notes": ""
      },
      {
        "title": "Two Sum In BST | Check if there exists a pair with Sum K",
        "links": [
          "https://leetcode.com/problems/two-sum-iv-input-is-a-bst/submissions/1336448045/"
        ],
        "solution": "./striver-solutions/topics/Tree/twoSumInBST.html",
        "notes": ""
      },
      {
        "title": "Recover BST | Correct BST with two nodes swapped",
        "links": [
          "https://leetcode.com/problems/recover-binary-search-tree/"
        ],
        "solution": "./striver-solutions/topics/Tree/RecoverBST.html",
        "notes": ""
      },
      {
        "title": "Largest BST in Binary Tree",
        "links": [
          "https://www.geeksforgeeks.org/problems/largest-bst/1"
        ],
        "solution": "./striver-solutions/topics/Tree/LargetsBSTInBT.html",
        "notes": ""
      }
    ]
  },
  {
    "id": "graphs",
    "name": "Graphs",
    "description": "Explore graph traversal, shortest paths, topological sorting, and DSU.",
    "symbol": "GR",
    "problems": [
      {
        "title": "Breadth-First Search (BFS)",
        "links": [
          "https://www.geeksforgeeks.org/problems/bfs-traversal-of-graph/1"
        ],
        "solution": "./striver-solutions/topics/Graph/bfsAlgo.html",
        "notes": ""
      },
      {
        "title": "Depth-First Search (DFS)",
        "links": [
          "https://www.geeksforgeeks.org/problems/depth-first-traversal-for-a-graph/1"
        ],
        "solution": "./striver-solutions/topics/Graph/DFS.html",
        "notes": ""
      },
      {
        "title": "Number of Provinces",
        "links": [
          "https://leetcode.com/problems/number-of-provinces/description/"
        ],
        "solution": "./striver-solutions/topics/Graph/NumberOfProvinces.html",
        "notes": ""
      },
      {
        "title": "Number of Islands",
        "links": [
          "https://leetcode.com/problems/number-of-islands/description/"
        ],
        "solution": "./striver-solutions/topics/Graph/NumberOfIsland.html",
        "notes": ""
      },
      {
        "title": "Flood Fill Algorithm",
        "links": [
          "https://leetcode.com/problems/flood-fill/description/"
        ],
        "solution": "./striver-solutions/topics/Graph/FloodFillAlgorithm.html",
        "notes": ""
      },
      {
        "title": "Rotten Oranges",
        "links": [
          "https://leetcode.com/problems/rotting-oranges/description/"
        ],
        "solution": "./striver-solutions/topics/Graph/RottenOranges.html",
        "notes": ""
      },
      {
        "title": "Detect a Cycle in an Undirected Graph using BFS/DFS",
        "links": [
          "https://www.geeksforgeeks.org/problems/detect-cycle-in-an-undirected-graph/1"
        ],
        "solution": "./striver-solutions/topics/Graph/detectCycleUsingBFS.html",
        "notes": ""
      },
      {
        "title": "Distance of nearest cell having 1 | 0/1 Matrix",
        "links": [
          "https://www.geeksforgeeks.org/problems/distance-of-nearest-cell-having-1-1587115620/1"
        ],
        "solution": "./striver-solutions/topics/Graph/DistanceOfNearestCell.html",
        "notes": ""
      },
      {
        "title": "Surrounded Regions | Replace O's with X's",
        "links": [
          "https://www.geeksforgeeks.org/problems/replace-os-with-xs0052/1"
        ],
        "solution": "./striver-solutions/topics/Graph/SurroundedRegions.html",
        "notes": ""
      },
      {
        "title": "Number of Enclaves",
        "links": [
          "https://leetcode.com/problems/number-of-enclaves/description/"
        ],
        "solution": "./striver-solutions/topics/Graph/NumberofEnclaves.html",
        "notes": ""
      },
      {
        "title": "Number of Distinct Islands",
        "links": [
          "https://www.geeksforgeeks.org/problems/number-of-distinct-islands/0"
        ],
        "solution": "./striver-solutions/topics/Graph/NumberofDistinctIslands.html",
        "notes": ""
      },
      {
        "title": "Bipartite Graph",
        "links": [
          "https://leetcode.com/problems/is-graph-bipartite/description/"
        ],
        "solution": "./striver-solutions/topics/Graph/BipartiteGraph.html",
        "notes": ""
      },
      {
        "title": "Detect cycle in a directed graph using DFS",
        "links": [
          "https://www.geeksforgeeks.org/problems/detect-cycle-in-a-directed-graph/1"
        ],
        "solution": "./striver-solutions/topics/Graph/detectCycleInDirectedGraph.html",
        "notes": ""
      },
      {
        "title": "Find Eventual Safe States",
        "links": [
          "https://www.geeksforgeeks.org/problems/eventual-safe-states/0"
        ],
        "solution": "./striver-solutions/topics/Graph/FindEventualSafeStates.html",
        "notes": "In this problem, focus which are terminal node, and nodes which are only ending up on the terminal node are safe node, if node are ending up on terminal node and on itself node as well then that is not the safe node. Terminal node: Node which has no outdegree or 0 outdegree"
      },
      {
        "title": "Topological Sort Algorithm",
        "links": [
          "https://www.geeksforgeeks.org/problems/topological-sort/1"
        ],
        "solution": "./striver-solutions/topics/Graph/TopologicalSortAlgo.html",
        "notes": "In Topological Sort Algo, We use Stack DS, So when we visit the node using DFS alog, and when all the nodes attacked to that node is over then we insert the node in the stack."
      },
      {
        "title": "Kahn's Algorithm | Topological Sort Algorithm",
        "links": [
          "https://www.geeksforgeeks.org/problems/topological-sort/1"
        ],
        "solution": "./striver-solutions/topics/Graph/kahnsAlgoForTopoAlgo.html",
        "notes": "In this we use BFS, and indegree graph. So first in the indegree graph we fill it by the indegree of the node. so which ever node has least indegree we insert those node first in the queue."
      },
      {
        "title": "Detect a Cycle in Directed Graph using BFS/Kanh's Algo",
        "links": [],
        "solution": "./striver-solutions/topics/Graph/detectCycleInDirectedGraphBFS.html",
        "notes": "Detect a Cycle in Directed Graph using BFS, needs to build this using kanh's algo"
      },
      {
        "title": "Course Schedule I| Prerequisite Tasks | Topological Sort",
        "links": [
          "https://leetcode.com/problems/course-schedule/"
        ],
        "solution": "./striver-solutions/topics/Graph/CourseSchedule.html",
        "notes": ""
      },
      {
        "title": "Course Schedule II | Prerequisite Tasks | Topological Sort",
        "links": [
          "https://www.geeksforgeeks.org/problems/course-schedule/1"
        ],
        "solution": "./striver-solutions/topics/Graph/CourseSchedule2.html",
        "notes": ""
      },
      {
        "title": "Alien Dictonary",
        "links": [
          "https://www.geeksforgeeks.org/problems/alien-dictionary/1"
        ],
        "solution": "./striver-solutions/topics/Graph/AlienDictonary.html",
        "notes": ""
      },
      {
        "title": "Shortest Path in Directed Acyclic Graph",
        "links": [
          "https://www.geeksforgeeks.org/problems/shortest-path-in-undirected-graph/0"
        ],
        "solution": "./striver-solutions/topics/Graph/shortestPathInDirectedAcyclicGraph.html",
        "notes": ""
      },
      {
        "title": "Shortest Path in Undirected Graph with Unit Weights",
        "links": [
          "https://www.geeksforgeeks.org/problems/shortest-path-in-undirected-graph-having-unit-distance/1"
        ],
        "solution": "./striver-solutions/topics/Graph/ShortestPathInUnDirectedGraphWithUnitWeight.html",
        "notes": ""
      },
      {
        "title": "Word Ladder - I | Shortest Path",
        "links": [
          "https://www.geeksforgeeks.org/problems/word-ladder/1"
        ],
        "solution": "./striver-solutions/topics/Graph/WordLadderI.html",
        "notes": ""
      },
      {
        "title": "Word Ladder - II | Shortest Path",
        "links": [
          "https://www.geeksforgeeks.org/problems/word-ladder-ii/1"
        ],
        "solution": "./striver-solutions/topics/Graph/WordLadderII.html",
        "notes": ""
      },
      {
        "title": "Dijkstra's Algorithm",
        "links": [
          "https://www.geeksforgeeks.org/problems/implementing-dijkstra-set-1-adjacency-matrix/1",
          "https://www.naukri.com/code360/problems/dijkstra-s-shortest-path_920469?count=25&page=1&search=&sort_entity=order&sort_order=ASC&leftPanelTabValue=PROBLEM"
        ],
        "solution": "./striver-solutions/topics/Graph/DijkstraAlgorithm.html",
        "notes": ""
      },
      {
        "title": "Dijkstra's Algorithm using set DS",
        "links": [
          "https://www.geeksforgeeks.org/problems/implementing-dijkstra-set-1-adjacency-matrix/1",
          "https://www.naukri.com/code360/problems/dijkstra-s-shortest-path_920469?count=25&page=1&search=&sort_entity=order&sort_order=ASC&leftPanelTabValue=PROBLEM"
        ],
        "solution": "./striver-solutions/topics/Graph/DijkstraAlgorithmUsingSetDS.html",
        "notes": "set ds is already sorted, to pick the top node we can fetch the first element from the set DS, using st.begin() -- it will give us the iterator pointing to the begining of the set"
      },
      {
        "title": "Print Shortest Path",
        "links": [
          "https://www.geeksforgeeks.org/problems/shortest-path-in-weighted-undirected-graph/1"
        ],
        "solution": "./striver-solutions/topics/Graph/PrintShortestPath.html",
        "notes": ""
      },
      {
        "title": "Shortest Distance in a Binary Maze",
        "links": [
          "https://bit.ly/3QLxjET"
        ],
        "solution": "./striver-solutions/topics/Graph/shortestPathInBinaryMaze.html",
        "notes": ""
      },
      {
        "title": "Path With Minimum Effort",
        "links": [
          "https://bit.ly/3dMBvq6"
        ],
        "solution": "./striver-solutions/topics/Graph/pathWithMinimumEfforts.html",
        "notes": ""
      },
      {
        "title": "Cheapest Flights Within K Stops",
        "links": [
          "https://bit.ly/3UIneer"
        ],
        "solution": "./striver-solutions/topics/Graph/CheapestFlightsWithinKStops.html",
        "notes": ""
      },
      {
        "title": "Minimum Multiplications to Reach End",
        "links": [
          "https://bit.ly/3AugzNb"
        ],
        "solution": "./striver-solutions/topics/Graph/MinimumMultiplicationstoReachEnd.html",
        "notes": ""
      },
      {
        "title": "Number of Ways to Arrive at Destination",
        "links": [
          "https://bit.ly/3Aro6Mq"
        ],
        "solution": "./striver-solutions/topics/Graph/NumberOfWaysToArriveDestination.html",
        "notes": ""
      },
      {
        "title": "Bellman Ford Algorithm",
        "links": [
          "https://bit.ly/3K7emug"
        ],
        "solution": "./striver-solutions/topics/Graph/BellmanFordAlgo.html",
        "notes": "this algo is used to find the shortest path which is similar to dijikstra algo, but this algo works in case of -ve edge, while dijikstra doesn't work with -ve edge"
      },
      {
        "title": "Floyd Warshall Algorithm",
        "links": [
          "https://bit.ly/3JZlk4a"
        ],
        "solution": "./striver-solutions/topics/Graph/floydWarshallAlgo.html",
        "notes": "In Floyd Warshall Algo, we find the shortest path from each nodes to each nodes. So let say in a graph it has 4 nodes: 0, 1, 2, 3. So algo is: from 0 node we try to figure out path to 0->1, 0->2, 0->3[here all path figure out via 0, means 0->1 via 0, 0->2 via 0, 0->3 via 0 then 0->1 via 1, 0->2 via 1, 0->3 via 1], then will find path from other nodes e.g. 2->0, 2->1, 2->3. [here 2->0, 2->1, 2->3 via 0| 2->0, 2->1, 2->3 via 1| 2->0, 2->1, 2->3 via 2| 2->0, 2->1, 2->3 via 3 Check the image in the Solution"
      },
      {
        "title": "Find the City With the Smallest Number of Neighbours at a Threshold Distance",
        "links": [
          "https://bit.ly/3PoGo5v"
        ],
        "solution": "./striver-solutions/topics/Graph/FindTheCity.html",
        "notes": ""
      },
      {
        "title": "Prism Algo to find Minimum Spanning Tree",
        "links": [
          "https://bit.ly/3ABwwRP"
        ],
        "solution": "./striver-solutions/topics/Graph/PrismAlgoToFindMST.html",
        "notes": "Spanning tree is where it has N node, N-1 Edges, and each nodes is reachable from each nodes. Minimum Spanning Tree: A **Minimum Spanning Tree (MST)** is a subset of the edges in a connected, undirected graph that connects all the vertices together without any cycles and with the minimum possible total edge weight. In simpler terms, it's a way of connecting all the points (or nodes) in a network with the least total distance or cost, without forming any loops."
      },
      {
        "title": "Disjoint Set | Union by Rank | Union by Size | Path Compression",
        "links": [],
        "solution": "./striver-solutions/topics/Graph/DisjointSet.html",
        "notes": ""
      },
      {
        "title": "Kruskal's Algorithm - Minimum Spanning Tree - C++ and Java",
        "links": [
          "https://bit.ly/3eLuYvH"
        ],
        "solution": "./striver-solutions/topics/Graph/kruskalAlgo.html",
        "notes": "Kruskal Algorith used to find the sum of MST, minimun spanning tree."
      },
      {
        "title": "Number of Operations to Make Network Connected - DSU",
        "links": [
          "https://bit.ly/3QGtkcd"
        ],
        "solution": "./striver-solutions/topics/Graph/connectTheGraph.html",
        "notes": ""
      },
      {
        "title": "Accounts Merge - DSU",
        "links": [
          "https://bit.ly/3sl2Xia"
        ],
        "solution": "./striver-solutions/topics/Graph/AccountsMergeDSU.html",
        "notes": ""
      },
      {
        "title": "Number of Islands - II - Online Queries - DSU",
        "links": [
          "https://bit.ly/3w9REfj"
        ],
        "solution": "./striver-solutions/topics/Graph/numberOfIslands2.html",
        "notes": ""
      },
      {
        "title": "Making a Large Island - DSU",
        "links": [
          "https://bit.ly/3xeLjzF"
        ],
        "solution": "./striver-solutions/topics/Graph/MakingLargeIsland.html",
        "notes": ""
      },
      {
        "title": "Most Stones Removed with Same Row or Column - DSU",
        "links": [
          "https://bit.ly/3QHZuE6"
        ],
        "solution": "./striver-solutions/topics/Graph/removeStone.html",
        "notes": ""
      },
      {
        "title": "Kosaraju Algo to find strong connected graph",
        "links": [
          "https://www.naukri.com/code360/problems/count-strongly-connected-components-kosaraju-s-algorithm_1171151?leftPanelTabValue=SUBMISSION"
        ],
        "solution": "./striver-solutions/topics/Graph/kosaraju.html",
        "notes": ""
      },
      {
        "title": "Critical Connections in a Network",
        "links": [
          "https://leetcode.com/problems/critical-connections-in-a-network/description/"
        ],
        "solution": "./striver-solutions/topics/Graph/CriticalConnectionInNetwork.html",
        "notes": ""
      },
      {
        "title": "Articulation Point in Graph",
        "links": [
          "https://bit.ly/3w9lfp1"
        ],
        "solution": "./striver-solutions/topics/Graph/articulationPointInGraph.html",
        "notes": "To find articulation point in a graph we will use tarzen algo logic with slight change."
      }
    ]
  },
  {
    "id": "sliding-window",
    "name": "Two Pointers & Sliding Window",
    "description": "Use two pointers and windows to solve array and string problems.",
    "symbol": "2P",
    "problems": [
      {
        "title": "Introduction to Sliding Window and 2 Pointers | Templates | Patterns",
        "links": [
          "https://www.youtube.com/watch?v=9kdHxplyl5I&list=PLgUwDviBIf0q7vrFA_HEWcqRqMpCXzYAL"
        ],
        "solution": "",
        "notes": ""
      },
      {
        "title": "Maximum Points You Can Obtain from Cards",
        "links": [
          "https://leetcode.com/problems/maximum-points-you-can-obtain-from-cards/description/"
        ],
        "solution": "./striver-solutions/topics/slidingWindow/maxPointsFromPickingCards.html",
        "notes": ""
      },
      {
        "title": "Longest Substring Without Repeating Characters",
        "links": [
          "https://leetcode.com/problems/longest-substring-without-repeating-characters/description/"
        ],
        "solution": "./striver-solutions/topics/slidingWindow/longesSubstringWOrepeatingchar.html",
        "notes": ""
      },
      {
        "title": "Max Consecutive Ones III",
        "links": [
          "https://leetcode.com/problems/max-consecutive-ones-iii/description/"
        ],
        "solution": "./striver-solutions/topics/slidingWindow/MaxConsecutiveOnes_III.html",
        "notes": ""
      },
      {
        "title": "Fruit Into Baskets",
        "links": [
          "https://leetcode.com/problems/fruit-into-baskets/description/"
        ],
        "solution": "./striver-solutions/topics/slidingWindow/FruitsIntoBuckets.html",
        "notes": ""
      },
      {
        "title": "Longest Substring With At Most K Distinct Characters",
        "links": [
          "https://bit.ly/3Mo2A0f"
        ],
        "solution": "./striver-solutions/topics/slidingWindow/longestSubstrWithKDistnChar.html",
        "notes": ""
      },
      {
        "title": "Number of Substrings Containing All Three Characters",
        "links": [
          "https://leetcode.com/problems/number-of-substrings-containing-all-three-characters/submissions/1379161771/"
        ],
        "solution": "./striver-solutions/topics/slidingWindow/NumberOfSubstrContainsAll3Char.html",
        "notes": ""
      },
      {
        "title": "Longest Repeating Character Replacement",
        "links": [
          "https://leetcode.com/problems/longest-repeating-character-replacement/description"
        ],
        "solution": "./striver-solutions/topics/slidingWindow/LongestRepeatingCharReplacement.html",
        "notes": ""
      },
      {
        "title": "Binary Subarrays With Sum",
        "links": [
          "https://leetcode.com/problems/binary-subarrays-with-sum/description/"
        ],
        "solution": "./striver-solutions/topics/slidingWindow/BinarySubarraysWithSum.html",
        "notes": ""
      },
      {
        "title": "Count number of Nice subarrays",
        "links": [
          "https://leetcode.com/problems/count-number-of-nice-subarrays/"
        ],
        "solution": "./striver-solutions/topics/slidingWindow/CountnumberofNicesubarrays.html",
        "notes": "This is similar problem to Binary Subarrays With Sum | 2 Pointers and Sliding Window Playlist Just some word twisting is done."
      },
      {
        "title": "Subarray with k different integers",
        "links": [
          "https://leetcode.com/problems/subarrays-with-k-different-integers/description/"
        ],
        "solution": "./striver-solutions/topics/slidingWindow/Subarraywithkdifferentintegers.html",
        "notes": ""
      },
      {
        "title": "Minimum Window Substring",
        "links": [
          "https://leetcode.com/problems/minimum-window-substring/"
        ],
        "solution": "./striver-solutions/topics/slidingWindow/MinimumWindowSubstring.html",
        "notes": ""
      },
      {
        "title": "Minimum Removals to Balance Array",
        "links": [
          "https://leetcode.com/problems/minimum-removals-to-balance-array/description/"
        ],
        "solution": "",
        "notes": ""
      }
    ]
  },
  {
    "id": "binary-search",
    "name": "Binary Search",
    "description": "Practice search boundaries and binary search on answers.",
    "symbol": "BS",
    "problems": [
      {
        "title": "Find the lower/upper bound index",
        "links": [
          "https://www.naukri.com/code360/problems/lower-bound_8165382?leftPanelTabValue=SUBMISSION"
        ],
        "solution": "./striver-solutions/topics/binarySearch/lowerBound_upperBound.html",
        "notes": "Lower bound the is the smallest index where arr[idx]>=x upper bound the is the smallest index where arr[idx]>x"
      },
      {
        "title": "Floor and Ciel value in Sorted array",
        "links": [
          "https://www.naukri.com/code360/problems/ceiling-in-a-sorted-array_1825401"
        ],
        "solution": "./striver-solutions/topics/binarySearch/floor_ciel_value.html",
        "notes": "Floor value is the largest element in the array where arr[ind] <= x Ciel value is the smallest element in the array where arr[ind] >= 0"
      },
      {
        "title": "First and Last Occurrences in Array",
        "links": [
          "https://leetcode.com/problems/find-first-and-last-position-of-element-in-sorted-array/description"
        ],
        "solution": "./striver-solutions/topics/binarySearch/occurance.html",
        "notes": ""
      },
      {
        "title": "Search Element in Rotated Sorted Array - I",
        "links": [
          "https://www.naukri.com/code360/problems/search-in-rotated-sorted-array_1082554?utm_source=youtube&utm_medium=affiliate&utm_campaign=codestudio_Striver_BinarySeries"
        ],
        "solution": "./striver-solutions/topics/binarySearch/SearchInRotatedSortedArray1.html",
        "notes": ""
      },
      {
        "title": "Search Element in Rotated Sorted Array II",
        "links": [
          "https://bit.ly/3MCdLTY"
        ],
        "solution": "./striver-solutions/topics/binarySearch/SearchElemInRotatedSortedArray2.html",
        "notes": ""
      },
      {
        "title": "Minimum in Rotated Sorted Array",
        "links": [
          "https://bit.ly/41My2dR"
        ],
        "solution": "./striver-solutions/topics/binarySearch/minElemInRotatedSortedArr.html",
        "notes": ""
      },
      {
        "title": "Minimum in Rotated Sorted Array II",
        "links": [
          "https://leetcode.com/problems/find-minimum-in-rotated-sorted-array-ii/description/"
        ],
        "solution": "./striver-solutions/topics/binarySearch/minElemInRotatedSortedArr2.html",
        "notes": ""
      },
      {
        "title": "Find out how many times array has been rotated",
        "links": [
          "https://www.naukri.com/code360/problems/rotation_7449070?utm_source=youtube&utm_medium=affiliate&utm_campaign=codestudio_Striver_BinarySeries"
        ],
        "solution": "./striver-solutions/topics/binarySearch/ArrayRotatedTimes.html",
        "notes": ""
      },
      {
        "title": "Single Element in Sorted Array",
        "links": [
          "https://bit.ly/42KKHj5"
        ],
        "solution": "./striver-solutions/topics/binarySearch/singelElemInsortedarray.html",
        "notes": ""
      },
      {
        "title": "Find Peak Element",
        "links": [
          "https://bit.ly/3BEDvZC"
        ],
        "solution": "./striver-solutions/topics/binarySearch/findPeakElem.html",
        "notes": ""
      },
      {
        "title": "Finding Sqrt of a number using Binary Search",
        "links": [
          "https://bit.ly/3J5dBCJ"
        ],
        "solution": "./striver-solutions/topics/binarySearch/sqrRoot.html",
        "notes": ""
      },
      {
        "title": "Find the Nth root of an Integer",
        "links": [
          "https://bit.ly/3oWhSkW"
        ],
        "solution": "./striver-solutions/topics/binarySearch/findNthRoot.html",
        "notes": ""
      },
      {
        "title": "Koko Eating Bananas",
        "links": [
          "https://www.naukri.com/code360/problems/minimum-rate-to-eat-bananas_7449064?utm_source=youtube&utm_medium=affiliate&utm_campaign=codestudio_Striver_BinarySeries"
        ],
        "solution": "./striver-solutions/topics/binarySearch/KokoEatingBananas.html",
        "notes": ""
      },
      {
        "title": "Minimum days to make M bouquets | Binary Search",
        "links": [
          "https://bit.ly/43ScDRY"
        ],
        "solution": "./striver-solutions/topics/binarySearch/minDayToMakeMBouquets.html",
        "notes": ""
      },
      {
        "title": "Smallest divisor",
        "links": [
          "https://www.naukri.com/code360/problems/smallest-divisor-with-the-given-limit_1755882?utm_source=youtube&utm_medium=affiliate&utm_campaign=codestudio_Striver_BinarySeries"
        ],
        "solution": "./striver-solutions/topics/binarySearch/Smallestdivisor.html",
        "notes": ""
      },
      {
        "title": "Capacity To Ship Packages Within D Days",
        "links": [
          "https://bit.ly/43QDpdG"
        ],
        "solution": "./striver-solutions/topics/binarySearch/minCapacityToShipPackageinDDays.html",
        "notes": ""
      },
      {
        "title": "Kth Missing Positive Number",
        "links": [
          "https://bit.ly/3p30UBg"
        ],
        "solution": "./striver-solutions/topics/binarySearch/kthMissingNumber.html",
        "notes": "How to understand and remeber this also: check its solution page"
      },
      {
        "title": "Aggressive Cows",
        "links": [
          "https://bit.ly/3J9ab1B"
        ],
        "solution": "./striver-solutions/topics/binarySearch/AggressiveCows.html",
        "notes": "Go Through the video if not understand the problem or solution"
      },
      {
        "title": "Allocate Books or Book Allocation",
        "links": [
          "https://www.naukri.com/code360/problems/allocate-books_1090540?utm_source=youtube&utm_medium=affiliate&utm_campaign=codestudio_Striver_BinarySeries"
        ],
        "solution": "./striver-solutions/topics/binarySearch/AllocateBooks.html",
        "notes": ""
      },
      {
        "title": "Painter's Partition",
        "links": [
          "https://bit.ly/3XM8oFS"
        ],
        "solution": "./striver-solutions/topics/binarySearch/painterPartition.html",
        "notes": "This question is exact similar to Allocate Books or Book Allocation problem"
      },
      {
        "title": "Split Array - Largest Sum",
        "links": [
          "https://bit.ly/3Ck7UwL"
        ],
        "solution": "./striver-solutions/topics/binarySearch/splitArray.html",
        "notes": "This question is exact similar to Allocate Books or Book Allocation problem"
      },
      {
        "title": "Minimize Max Distance to Gas Station",
        "links": [
          "https://bit.ly/43SkwqA"
        ],
        "solution": "./striver-solutions/topics/binarySearch/MinimizeMaxDisttoGasStation.html",
        "notes": "Prefer priority queque solution, that is easy to understand"
      },
      {
        "title": "BS-21. Median of two Sorted Arrays of Different Sizes | Binary Search",
        "links": [
          "https://bit.ly/43QDw96"
        ],
        "solution": "./striver-solutions/topics/binarySearch/medianOf2SortedArray.html",
        "notes": ""
      },
      {
        "title": "K-th element of two sorted arrays",
        "links": [
          "https://bit.ly/3MD3mHK"
        ],
        "solution": "./striver-solutions/topics/binarySearch/kthElemOf2SortedArr.html",
        "notes": ""
      },
      {
        "title": "Row with maximum number of 1s",
        "links": [
          "https://bit.ly/3P0n95t"
        ],
        "solution": "./striver-solutions/topics/binarySearch/rowsWithMaxNumberOf1s.html",
        "notes": ""
      },
      {
        "title": "Search in a 2D Matrix - I",
        "links": [
          "https://leetcode.com/problems/search-a-2d-matrix/"
        ],
        "solution": "./striver-solutions/topics/binarySearch/searchIn2DMatrix_I.html",
        "notes": ""
      },
      {
        "title": "Search in a 2D Matrix - II",
        "links": [
          "https://leetcode.com/problems/search-a-2d-matrix-ii/submissions/1384047949/"
        ],
        "solution": "./striver-solutions/topics/binarySearch/searchIn2DMatrix_II.html",
        "notes": ""
      },
      {
        "title": "Find Peak Element-II | Binary Search",
        "links": [
          "https://bit.ly/3Ckb4Rb"
        ],
        "solution": "./striver-solutions/topics/binarySearch/FindPeakElement_II.html",
        "notes": ""
      },
      {
        "title": "Median in a Row Wise Sorted Matrix",
        "links": [
          "https://bit.ly/4ghD5vq"
        ],
        "solution": "./striver-solutions/topics/binarySearch/medianInRowWiseSortedMatrix.html",
        "notes": ""
      }
    ]
  },
  {
    "id": "sorting",
    "name": "Sorting",
    "description": "Understand elementary, divide-and-conquer, and comparison sorting.",
    "symbol": "SO",
    "problems": [
      {
        "title": "BubbleSort",
        "links": [
          "https://www.naukri.com/code360/problems/bubble-sort_980524?leftPanelTabValue=PROBLEM"
        ],
        "solution": "./striver-solutions/topics/Sorting/BubbleSort.html",
        "notes": ""
      },
      {
        "title": "Selection Sort",
        "links": [
          "https://www.naukri.com/code360/problems/selection-sort_981162"
        ],
        "solution": "./striver-solutions/topics/Sorting/SelectionSort.html",
        "notes": ""
      },
      {
        "title": "Insertion Sort",
        "links": [
          "https://www.naukri.com/code360/problems/insertion-sort_3155179?leftPanelTabValue=PROBLEM"
        ],
        "solution": "./striver-solutions/topics/Sorting/InsertionSort.html",
        "notes": ""
      },
      {
        "title": "Counting Sort",
        "links": [
          "https://www.naukri.com/code360/problems/counting-sort_2663351"
        ],
        "solution": "./striver-solutions/topics/Sorting/CountingSort.html",
        "notes": ""
      },
      {
        "title": "Merge Sort",
        "links": [
          "https://www.naukri.com/code360/problems/merge-sort_920442?leftPanelTabValue=PROBLEM"
        ],
        "solution": "./striver-solutions/topics/Sorting/MergeSort.html",
        "notes": ""
      },
      {
        "title": "Quick Sort",
        "links": [
          "https://www.naukri.com/code360/problems/quick-sort_983625"
        ],
        "solution": "./striver-solutions/topics/Sorting/QuickSort.html",
        "notes": ""
      }
    ]
  },
  {
    "id": "stacks-queues",
    "name": "Stacks & Queues",
    "description": "Apply monotonic stacks, queues, and queue-based design patterns.",
    "symbol": "SQ",
    "problems": [
      {
        "title": "Check for Balanced Parentheses | Stack and Queue",
        "links": [
          "https://leetcode.com/problems/valid-parentheses/description/"
        ],
        "solution": "./striver-solutions/topics/StackNQueue/checkParenthesis.html",
        "notes": ""
      },
      {
        "title": "Conversion - Infix to Postfix, Infix to Prefix and so on",
        "links": [
          "https://www.naukri.com/code360/problems/day-23-:-infix-to-postfix-_1382146?leftPanelTabValue=PROBLEM"
        ],
        "solution": "./striver-solutions/topics/StackNQueue/conversions.html",
        "notes": ""
      },
      {
        "title": "Min Stack",
        "links": [
          "https://leetcode.com/problems/min-stack/description/"
        ],
        "solution": "./striver-solutions/topics/StackNQueue/minstack.html",
        "notes": ""
      },
      {
        "title": "Next Greater Element",
        "links": [
          "https://www.naukri.com/code360/problems/next-greater-element_670312?leftPanelTabValue=PROBLEM"
        ],
        "solution": "./striver-solutions/topics/StackNQueue/NGE.html",
        "notes": ""
      },
      {
        "title": "Next Greater Element II",
        "links": [
          "https://leetcode.com/problems/next-greater-element-ii/description/"
        ],
        "solution": "./striver-solutions/topics/StackNQueue/nge2.html",
        "notes": ""
      },
      {
        "title": "Smaller on Left",
        "links": [
          "https://www.geeksforgeeks.org/problems/smallest-number-on-left3403/1?itm_source=geeksforgeeks&itm_medium=article&itm_campaign=practice_card"
        ],
        "solution": "./striver-solutions/topics/StackNQueue/smallerOnLeft.html",
        "notes": ""
      },
      {
        "title": "Trapping Rain Water",
        "links": [
          "https://leetcode.com/problems/trapping-rain-water/description/"
        ],
        "solution": "./striver-solutions/topics/StackNQueue/trapRain.html",
        "notes": ""
      },
      {
        "title": "Sum of Subarray Minimum",
        "links": [
          "https://leetcode.com/problems/sum-of-subarray-minimums/description/"
        ],
        "solution": "./striver-solutions/topics/StackNQueue/SumofSubarrayMinimum.html",
        "notes": ""
      },
      {
        "title": "Sum of Subarray Ranges",
        "links": [
          "https://leetcode.com/problems/sum-of-subarray-ranges/"
        ],
        "solution": "./striver-solutions/topics/StackNQueue/SumofSubarrayRanges.html",
        "notes": ""
      },
      {
        "title": "Asteroid Collision",
        "links": [
          "https://leetcode.com/problems/asteroid-collision/"
        ],
        "solution": "./striver-solutions/topics/StackNQueue/AsteroidCollision.html",
        "notes": ""
      },
      {
        "title": "Largest Rectangle in Histogram",
        "links": [
          "https://leetcode.com/problems/largest-rectangle-in-histogram/description/"
        ],
        "solution": "./striver-solutions/topics/StackNQueue/LargestRectangleInHistogram.html",
        "notes": ""
      },
      {
        "title": "Maximal Rectangle",
        "links": [
          "https://leetcode.com/problems/maximal-rectangle/description/"
        ],
        "solution": "./striver-solutions/topics/StackNQueue/MaximalRectangle.html",
        "notes": ""
      },
      {
        "title": "Remove K Digits",
        "links": [
          "https://leetcode.com/problems/remove-k-digits/description/"
        ],
        "solution": "./striver-solutions/topics/StackNQueue/RemoveKDigits.html",
        "notes": ""
      },
      {
        "title": "Stock Span Problem",
        "links": [
          "https://leetcode.com/problems/online-stock-span/description/"
        ],
        "solution": "./striver-solutions/topics/StackNQueue/StockSpan.html",
        "notes": ""
      },
      {
        "title": "Sliding Window Maximum",
        "links": [
          "https://leetcode.com/problems/sliding-window-maximum/description/"
        ],
        "solution": "./striver-solutions/topics/StackNQueue/SlidingWindowMaximum.html",
        "notes": ""
      },
      {
        "title": "The Celebrity Problem",
        "links": [
          "https://www.geeksforgeeks.org/problems/the-celebrity-problem/1?itm_source=geeksforgeeks&itm_medium=article&itm_campaign=practice_card"
        ],
        "solution": "./striver-solutions/topics/StackNQueue/celebrityProblem.html",
        "notes": ""
      },
      {
        "title": "Implement LRU Cache",
        "links": [
          "https://leetcode.com/problems/lru-cache/description/"
        ],
        "solution": "./striver-solutions/topics/StackNQueue/LRUCache.html",
        "notes": ""
      },
      {
        "title": "LFU Cache",
        "links": [
          "https://leetcode.com/problems/lfu-cache/description/"
        ],
        "solution": "./striver-solutions/topics/StackNQueue/LFUCache.html",
        "notes": ""
      },
      {
        "title": "LRU Thread Safe",
        "links": [
          "https://leetcode.com/problems/lru-cache/description/"
        ],
        "solution": "./striver-solutions/topics/StackNQueue/LRUThreadSafe.html",
        "notes": ""
      },
      {
        "title": "LFU Thread Cache",
        "links": [
          "https://leetcode.com/problems/lfu-cache/description/"
        ],
        "solution": "./striver-solutions/topics/StackNQueue/LFUThreadSafe.html",
        "notes": ""
      }
    ]
  },
  {
    "id": "greedy",
    "name": "Greedy",
    "description": "Recognize local-choice strategies, intervals, and scheduling problems.",
    "symbol": "GY",
    "problems": [
      {
        "title": "Assign Cookies",
        "links": [
          "https://leetcode.com/problems/assign-cookies/"
        ],
        "solution": "./striver-solutions/topics/Greedy/assignCookies.html",
        "notes": ""
      },
      {
        "title": "Lemonade Change",
        "links": [
          "https://leetcode.com/problems/lemonade-change/description/"
        ],
        "solution": "./striver-solutions/topics/Greedy/LemonadeChange.html",
        "notes": ""
      },
      {
        "title": "Shortest Job First (or SJF) CPU Scheduling",
        "links": [
          "https://www.geeksforgeeks.org/problems/shortest-job-first/1?utm_source=youtube&utm_medium=collab_striver_ytdescription&utm_campaign=shortest-job-first"
        ],
        "solution": "./striver-solutions/topics/Greedy/SJF.html",
        "notes": ""
      },
      {
        "title": "JumpGame1",
        "links": [
          "https://leetcode.com/problems/jump-game/description/"
        ],
        "solution": "./striver-solutions/topics/Greedy/JumpGame1.html",
        "notes": ""
      },
      {
        "title": "JumpGame2",
        "links": [
          "https://leetcode.com/problems/jump-game-ii/description/"
        ],
        "solution": "./striver-solutions/topics/Greedy/JumpGame2.html",
        "notes": ""
      },
      {
        "title": "Job Sequencing Problem",
        "links": [
          "https://www.naukri.com/code360/problems/job-sequencing-problem_1169460?leftPanelTabValue=PROBLEM"
        ],
        "solution": "./striver-solutions/topics/Greedy/JobSequencing.html",
        "notes": ""
      },
      {
        "title": "N Meeting in One Room",
        "links": [
          "https://leetcode.com/problems/maximum-length-of-pair-chain/description/"
        ],
        "solution": "./striver-solutions/topics/Greedy/NMeetingInOneroom.html",
        "notes": ""
      },
      {
        "title": "Non Overlapping Intervals",
        "links": [
          "https://leetcode.com/problems/non-overlapping-intervals/description/"
        ],
        "solution": "./striver-solutions/topics/Greedy/nonOverLappingIntervals.html",
        "notes": "This problem is similar to prev problem[N Meeting in One Room]"
      },
      {
        "title": "insert intervals",
        "links": [
          "https://leetcode.com/problems/insert-interval/description/"
        ],
        "solution": "./striver-solutions/topics/Greedy/insertintervals.html",
        "notes": ""
      },
      {
        "title": "Minimum number of platforms required in a railway station",
        "links": [
          "https://www.geeksforgeeks.org/problems/minimum-platforms-1587115620/1?itm_source=geeksforgeeks&itm_medium=article&itm_campaign=practice_card"
        ],
        "solution": "./striver-solutions/topics/Greedy/minimumPlatform.html",
        "notes": ""
      },
      {
        "title": "Valid Parenthesis String",
        "links": [
          "https://leetcode.com/problems/valid-parenthesis-string/description/"
        ],
        "solution": "./striver-solutions/topics/Greedy/validParenthesis.html",
        "notes": ""
      },
      {
        "title": "Candy Problem",
        "links": [
          "https://leetcode.com/problems/candy/"
        ],
        "solution": "./striver-solutions/topics/Greedy/CandyProblem.html",
        "notes": ""
      },
      {
        "title": "Fractional Knapsack Algorithm",
        "links": [
          "https://www.geeksforgeeks.org/problems/fractional-knapsack-1587115620/1"
        ],
        "solution": "./striver-solutions/topics/Greedy/FractionalKnapsackAlgo.html",
        "notes": ""
      }
    ]
  },
  {
    "id": "bit-manipulation",
    "name": "Bit Manipulation",
    "description": "Build confidence with binary representations, XOR, and bit operations.",
    "symbol": "BT",
    "problems": [
      {
        "title": "Decimal to binary",
        "links": [
          "https://www.geeksforgeeks.org/problems/decimal-to-binary-1587115620/1"
        ],
        "solution": "./striver-solutions/topics/Bitmanipulation/d2b.html",
        "notes": ""
      },
      {
        "title": "Binary to Decimal",
        "links": [
          "https://www.geeksforgeeks.org/problems/binary-number-to-decimal-number3525/0"
        ],
        "solution": "./striver-solutions/topics/Bitmanipulation/b2d.html",
        "notes": ""
      },
      {
        "title": "Bit Operations",
        "links": [],
        "solution": "./striver-solutions/topics/Bitmanipulation/bitOperations.html",
        "notes": ""
      },
      {
        "title": "Minimum Bit Flips to Convert Number",
        "links": [
          "https://leetcode.com/problems/minimum-bit-flips-to-convert-number/description/"
        ],
        "solution": "./striver-solutions/topics/Bitmanipulation/MinBitFlipsToGoal.html",
        "notes": ""
      },
      {
        "title": "Power Set",
        "links": [
          "https://www.geeksforgeeks.org/problems/power-set4302/1?itm_source=geeksforgeeks&itm_medium=article&itm_campaign=practice_card"
        ],
        "solution": "./striver-solutions/topics/Bitmanipulation/powerSet.html",
        "notes": ""
      },
      {
        "title": "Single Number",
        "links": [
          "https://leetcode.com/problems/single-number/description/"
        ],
        "solution": "./striver-solutions/topics/Bitmanipulation/SingleNumber.html",
        "notes": ""
      },
      {
        "title": "Single Numer 2",
        "links": [
          "https://leetcode.com/problems/single-number-ii/description/"
        ],
        "solution": "./striver-solutions/topics/Bitmanipulation/singleNumber2.html",
        "notes": ""
      },
      {
        "title": "Single Number 3",
        "links": [
          "https://leetcode.com/problems/single-number-iii/description/"
        ],
        "solution": "./striver-solutions/topics/Bitmanipulation/singleNumber3.html",
        "notes": "Go to video to understand the concept"
      },
      {
        "title": "XOR of Numbers in a Given Range",
        "links": [],
        "solution": "./striver-solutions/topics/Bitmanipulation/xorOfGivenRange.html",
        "notes": ""
      },
      {
        "title": "Divide Two Integers",
        "links": [
          "https://leetcode.com/problems/divide-two-integers/description/"
        ],
        "solution": "./striver-solutions/topics/Bitmanipulation/DivideTwoIntegers.html",
        "notes": ""
      }
    ]
  },
  {
    "id": "maths",
    "name": "Maths",
    "description": "Strengthen number theory, primes, modular arithmetic, and combinatorics.",
    "symbol": "MX",
    "problems": [
      {
        "title": "Prime Number",
        "links": [
          "https://www.geeksforgeeks.org/problems/prime-number2314/1"
        ],
        "solution": "./striver-solutions/topics/Maths/PrimeNumber.html",
        "notes": ""
      },
      {
        "title": "All prime factors of a number",
        "links": [
          "https://www.geeksforgeeks.org/problems/prime-factors5052/0"
        ],
        "solution": "./striver-solutions/topics/Maths/primefactors.html",
        "notes": ""
      },
      {
        "title": "Power Exponentiation",
        "links": [
          "https://leetcode.com/problems/powx-n/description/"
        ],
        "solution": "./striver-solutions/topics/Maths/PowerExponentiation.html",
        "notes": ""
      },
      {
        "title": "Sieve of Eratosthenes",
        "links": [
          "https://www.geeksforgeeks.org/problems/sieve-of-eratosthenes5242/1"
        ],
        "solution": "./striver-solutions/topics/Maths/SieveofEratosthenes.html",
        "notes": ""
      },
      {
        "title": "Count Prime in range",
        "links": [],
        "solution": "./striver-solutions/topics/Maths/CountPrimeInRange.html",
        "notes": ""
      }
    ]
  }
];
